//
// Created by Borelset on 2023/7/13.
//

#ifndef SIMBASEDREORDER_ATHENCODING_H
#define SIMBASEDREORDER_ATHENCODING_H

uint32_t ByteMask[4] = {
        0xff000000,
        0x00ff0000,
        0x0000ff00,
        0x000000ff,
};

uint8_t getByte(uint32_t value, int pos){
  value = value & ByteMask[pos];
  return value >> (8*(pos-3));
}

struct EncodeOutput{
    uint8_t output[8] = {0, 0, 0, 0, 0, 0, 0, 0};
    int length = 0;

    void write(uint8_t value){
      output[length] = value;
      length++;
    }
};

struct DecodeOutput{
    uint8_t output[8] = {0, 0, 0, 0, 0, 0, 0, 0};
    int length = 0;
    int bitPos = 0;
    int usedLength = 0;

    void write(int bit){
      output[length] = output[length] | (bit << bitPos);
      bitPos++;
      if(bitPos == 8){
        length++;
        bitPos = 0;
      }
    }

    void flush(){

    }
};

struct Ratio{
    uint32_t ratio = 0;
    int count = 0;

    Ratio(int initRatio){
      ratio = initRatio;
      ratio = ratio << 10;
    }
    int update(int bit){
      int delta = (((bit << 22) - ratio)*2);
      int update = delta/(count+count+20);
      assert(update + ratio >= 0);
      ratio = update + ratio;
      ratio = ratio & 0x003fffff;
      count++;
    }

    int getRatio(){
      return ratio >> 10;
    }
};

EncodeOutput AthEncoding(uint64_t value, int datumBit, int ratio){
  EncodeOutput result;
  uint32_t x1 = 0, x2 = UINT32_MAX;
  Ratio pr(ratio);
  int tailBoundary = datumBit/3;
  for(int i=0; i<datumBit-tailBoundary; i++){
    int bit = (value & 0x01);
    value = value >> 1;
    uint32_t xMid = x1 + ((x2-x1)>>12)*pr.getRatio() + (((x2-x1)&0xfff)*pr.getRatio()>>12);
    bit ? (x2=xMid) : (x1=xMid+1);
    pr.update(bit);
    while (((x1^x2)&0xff000000)==0) {
      result.write(x1>>24);
      x1<<=8;
      x2=(x2<<8)+255;
    }
  }
  for(int i=0; i<tailBoundary; i++){
    int currentRatio = (pr.getRatio() - 1) / tailBoundary * (tailBoundary - i - 1) + 1;
    int bit = (value & 0x01);
    value = value >> 1;
    uint32_t xMid = x1 + ((x2-x1)>>12)*currentRatio + (((x2-x1)&0xfff)*currentRatio>>12);
    bit ? (x2=xMid) : (x1=xMid+1);
    pr.update(bit);
    while (((x1^x2)&0xff000000)==0) {
      result.write(x1>>24);
      x1<<=8;
      x2=(x2<<8)+255;
    }
  }
  for(int i=0; i<4; i++){
    uint32_t head1 = x1 >> (8*(3-i));
    uint32_t head2 = x2 >> (8*(3-i));
    if(head2 - head1 > 1) {
      result.write(getByte(x1, i)+1);
      break;
    }else{
      result.write(getByte(x1, i)+1);
    }
  }


  return result;
}

DecodeOutput AthDecoding(uint8_t* output, int datumBit, int ratio){
  uint32_t x1 = 0, x2 = UINT32_MAX;
  uint32_t x = 0;
  int pos = 0, usedLength = 0;
  for(int i=0; i<4; i++){
    x = (x<<8) + output[i];
    pos++;
  }

  DecodeOutput result;

  int tailBoundary = datumBit / 3;
  for(int i=0; i<datumBit - tailBoundary; i++){
    int bit;
    uint32_t xmid = x1 + ((x2-x1)>>12)*ratio + (((x2-x1)&0xfff)*ratio>>12);
    bit = (x<=xmid);
    bit ? (x2=xmid) : (x1=xmid+1);
    while (((x1^x2)&0xff000000)==0) {
      x1<<=8;
      x2=(x2<<8)+255;
      x=(x<<8)+(output[pos++]);
      usedLength++;
    }
    result.write(bit);
  }
  for(int i=0; i<tailBoundary; i++){
    int currentRatio = (ratio - 1) / tailBoundary * (tailBoundary - i - 1) + 1;
    int bit;
    uint32_t xmid = x1 + ((x2-x1)>>12)*currentRatio + (((x2-x1)&0xfff)*currentRatio>>12);
    bit = (x<=xmid);
    bit ? (x2=xmid) : (x1=xmid+1);
    while (((x1^x2)&0xff000000)==0) {
      x1<<=8;
      x2=(x2<<8)+255;
      x=(x<<8)+(output[pos++]);
      usedLength++;
    }
    result.write(bit);
  }
  result.usedLength = usedLength+1;

  return result;
}

#endif //SIMBASEDREORDER_ATHENCODING_H
