//
// Created by Borelset on 2023/6/29.
//

#ifndef SIMBASEDREORDER_BATCHREORDER_H
#define SIMBASEDREORDER_BATCHREORDER_H

#include <cstring>

#define EqualRatio (1/256)

struct LinearPara{
    float para_b, para_k;
};

struct ReorderResult{
    std::vector<uint64_t> linearValues;
    std::vector<uint64_t> directValues;
    std::vector<int> orders;
    std::vector<int> linearLevels;
    LinearPara paras;
    int linearMin;
    int directMin;
    int maxLength;
    int maxOrder;
    int directMaxLength;
};


struct SequenceStruct{
    SequenceStruct(int x, int y){
      order = x, value = y;
    }

    SequenceStruct(){
      order = 0, value = 0;
    }

    int order;
    int value;
};

bool SeqComparor(const SequenceStruct& lh, const SequenceStruct& rh){
  return lh.value < rh.value;
}

struct PriorityRecorder{
    PriorityRecorder(int x, int y){
      priority = x, oldOrder = y;
    }
    PriorityRecorder(){
      priority = 0, oldOrder = 0;
    }

    float priority;
    float oldOrder;
};

bool PriComparor(const PriorityRecorder& lh, const PriorityRecorder& rh){
  return lh.priority < rh.priority;
}

std::vector<int> intervalPop(const std::vector<uint64_t>& values, int interval){
  std::vector<int> result;
  int maxNumber = 0, maxp1 = 0, maxp2 = 0;
  int pos1 = 0, pos2 = 0, num = 1;
  int endPos = values.size()-1;
  while(1){
    if(values[pos2] - values[pos1] <= interval){
      if(num > maxNumber){
        maxNumber = num;
        maxp1 = pos1;
        maxp2 = pos2;
      }
      pos2++;
      num++;
    }else{
      num--;
      pos1++;
      if(num > maxNumber){
        maxNumber = num;
        maxp1 = pos1;
        maxp2 = pos2;
      }
    }
    if(pos2 > endPos) break;
  }

  for(int i=0; i<maxp1; i++){
    result.push_back(i);
  }
  for(int i=maxp2; i<=endPos; i++){
    result.push_back(i);
  }
  return result;
}

std::string ReorderResultToString(const std::vector<ReorderResult>& data, int batchsize, int colNum){
  std::vector<int> FinalLengths;
  std::vector<int> orders;
  std::vector<std::vector<int>> remainPos;

  for(auto item: data){
    int orderLength = 0;
    while(1){
      if(((item.maxOrder + 1) >> orderLength) == 0){
        break;
      }
      orderLength++;
    }

    if(item.directMaxLength <= 8){
      FinalLengths.push_back(1);
      orders.push_back(0);
      continue;
    }else if(orderLength + item.maxLength <= 8){
      FinalLengths.push_back(1);
      orders.push_back(orderLength);
      continue;
    }else if (orderLength + item.maxLength <= 16){
      int number = item.linearValues.size();
      auto popResult = intervalPop(item.linearValues, 256);
      if(popResult.size() < (number*1/4)) {
        FinalLengths.push_back(2);
        orders.push_back(orderLength);
        remainPos.push_back(popResult);
      }else{
        FinalLengths.push_back(1);
        orders.push_back(orderLength);
      }
      continue;
    }else if(item.directMaxLength <= 16){
      FinalLengths.push_back(2);
      orders.push_back(0);
      continue;
    }else if (orderLength + item.maxLength <= 24){
      int number = item.linearValues.size();
      auto popResult = intervalPop(item.linearValues, 256);
      if(popResult.size() < number*2/4) {
        FinalLengths.push_back(1);
        orders.push_back(orderLength);
        remainPos.push_back(popResult);
        continue;
      }
      popResult = intervalPop(item.linearValues, 256*256);
      if(popResult.size() < number*1/4) {
        FinalLengths.push_back(2);
        orders.push_back(orderLength);
        remainPos.push_back(popResult);
        continue;
      }else{
        FinalLengths.push_back(3);
        orders.push_back(orderLength);
        continue;
      }
    }else if(item.directMaxLength <= 24){
      FinalLengths.push_back(3);
      orders.push_back(0);
      continue;
    }else if(orderLength + item.maxLength <= 32){
      int number = item.linearValues.size();
      auto popResult = intervalPop(item.linearValues, 256);
      if(popResult.size() < number*3/4) {
        FinalLengths.push_back(1);
        orders.push_back(orderLength);
        remainPos.push_back(popResult);
        continue;
      }
      popResult = intervalPop(item.linearValues, 256*256);
      if(popResult.size() < number*2/4) {
        FinalLengths.push_back(2);
        orders.push_back(orderLength);
        remainPos.push_back(popResult);
        continue;
      }
      popResult = intervalPop(item.linearValues, 256*256*256);
      if(popResult.size() < number*1/4) {
        FinalLengths.push_back(3);
        orders.push_back(orderLength);
        remainPos.push_back(popResult);
        continue;
      }else{
        FinalLengths.push_back(3);
        orders.push_back(orderLength);
        continue;
      }
    }else if(item.directMaxLength <= 32){
      FinalLengths.push_back(4);
      orders.push_back(0);
      continue;
    }else{
      assert(0);
    }
  }

  std::string result;
  char buffer[16];

  int state = 0;
  char temp = 0x00;
  for(int i=0; i<colNum; i++){
    uint8_t num = orders[i];
    if(state == 0){
      temp = num << 4;
      state = 1;
    }else{
      temp = temp | num;
      result.append(temp, 1);
      temp = 0;
      state = 0;
    }
  }
  if(state) result.append(temp, 1);

  state = 0;
  temp = 0x00;
  for(int i=0; i<colNum; i++){
    uint8_t ll = FinalLengths[i];
    temp = ll << ((3-state)*2);
    state = (state+1)%4;
    if(state == 0){
      result.append(temp, 1);
    }
  }
  if(state) result.append(temp,1);

  for(int i=0; i<colNum; i++){
    if(orders[i] != 0){
      memcpy(buffer, &(data[i].paras), sizeof(data[i].paras));
      result.append(buffer, sizeof(data[i].paras));
    }
  }

  for(int i=0; i<colNum; i++){
    if(orders[i] == 0){
      memcpy(buffer, &(data[i].directMin), sizeof(data[i].directMin));
      result.append(buffer, sizeof(data[i].directMin));
    }else{
      memcpy(buffer, &(data[i].linearMin), sizeof(data[i].linearMin));
      result.append(buffer, sizeof(data[i].linearMin));
    }
  }

  for(int i=0; i<colNum; i++){
    for(int j=0; j<batchsize; j++){
      if(orders[i] == 0){
        memcpy(buffer, &(data[i].directValues[j]), FinalLengths[i]);
        result.append(buffer, FinalLengths[i]);
      }else{
        int shift = FinalLengths[i]*8 - orders[i];
        uint64_t header = data[i].orders[j] << shift;
        uint64_t finalValue = header | data[i].linearValues[j];
        memcpy(buffer, &finalValue, FinalLengths[i]);
        result.append(buffer, FinalLengths[i]);
      }
    }
  }

  return result;
}


double corr(const std::vector<SequenceStruct>& col1, const std::vector<SequenceStruct>& col2, int number){
  double cov = 0.0;
  double d1 = 0.0, d2 = 0.0;
  double e1 = 0.0, e2 = 0.0;

  for(int i=0; i<number; i++){
    e1 += col1[i].order;
    e2 += col2[i].order;
    cov += col1[i].order * col2[i].order;
  }
  e1 /= number; //E(X)
  e2 /= number; //E(Y)
  cov /= number; // E(XY)
  cov = cov - e1*e2; // E(XY) - E(X)E(Y)

  for(int i=0; i<number; i++){
    d1 += pow(col1[i].order - e1, 2);
    d2 += pow(col2[i].order - e2, 2);
  }
  d1 /= number;
  d2 /= number;

  return cov/(sqrt(d1)*sqrt(d2));
}

std::vector<std::vector<int64_t>>
BatchReorder(const std::vector<std::vector<int64_t>> &data, uint64_t startLine, int batchsize, int colNum) {
  std::vector<std::vector<SequenceStruct>> OrderMatrix(colNum);
  for(int i=0; i<colNum; i++){
    for(int j=0; j<batchsize; j++){
      OrderMatrix[i].push_back({0, 0});
    }
  }

  for(int n = 0; n<colNum; n++){
    std::vector<SequenceStruct> temp(batchsize);
    // 构造序数表
    for(int i=0; i<batchsize; i++){
      temp[i].value = data[n][startLine + i];
    }

    std::sort(temp.begin(), temp.end(), SeqComparor);

    for(int i=0; i<batchsize; i++){
      if(i >= 1 && (temp[i].value == temp[i-1].value)) {
        temp[i].order = temp[i-1].order;
      }else{
        temp[i].order = i;
      }
    }

    for(int i=0; i<batchsize; i++){
      int64_t test = data[n][startLine + i];
      OrderMatrix[n][i].value = test;
      for(int j=0; j<batchsize; j++){
        if(temp[j].value == OrderMatrix[n][i].value) {
          OrderMatrix[n][i].order = temp[j].order;
          break;
        }
      }
    }
  }

  // 判断列之间的正负相关关系
  std::vector<double> relativeRelationship(colNum);
  for(int i=0; i<colNum; i++){
    relativeRelationship[i] = corr(OrderMatrix[i], OrderMatrix[0], batchsize);
  }
  //负相关则order转向
  for(int i=1; i<colNum; i++){
    if(relativeRelationship[i] < 0){
      for(int j=0; j<batchsize; j++){
        OrderMatrix[i][j].order = batchsize-1 - OrderMatrix[i][j].order;
      }
    }
  }

  //统计优先级
  std::vector<PriorityRecorder> priority(batchsize);
  for(int j=0; j < batchsize; j++){
    priority[j].oldOrder = j;
  }
  for(int j=0; j < batchsize; j++){
    for(int i=0; i<colNum; i++){
      priority[j].priority += OrderMatrix[i][j].order;
    }
  }
  // 优先级排序
  std::sort(priority.begin(), priority.end(), PriComparor);

  std::vector<std::vector<int64_t>> result(colNum);
  for(int i=0; i<colNum; i++){
    for(int j=0; j < batchsize; j++){
      result[i].push_back(0);
    }
  }

//  printf("new\n");
  for(int j=0; j<batchsize; j++){
    int oldOrder = priority[j].oldOrder;
    for(int i=0; i<colNum; i++){
      result[i][j] = data[i][startLine + oldOrder];
//      printf("%ld ", result[i][j]);
    }
//    printf("\n");
  }

  return result;
}

std::vector<std::vector<int64_t>>
BatchReorder2(const std::vector<std::vector<int64_t>> &data, uint64_t startLine, int batchsize, int colNum, std::vector<bool>* valid) {
  std::vector<std::vector<SequenceStruct>> OrderMatrix(colNum);
  for(int i=0; i<colNum; i++){
    for(int j=0; j<batchsize; j++){
      OrderMatrix[i].push_back({0, 0});
    }
  }

  for(int n = 0; n<colNum; n++){
    std::vector<SequenceStruct> temp(batchsize);
    // 构造序数表
    for(int i=0; i<batchsize; i++){
      temp[i].value = data[n][startLine + i];
    }

    std::sort(temp.begin(), temp.end(), SeqComparor);

    for(int i=0; i<batchsize; i++){
      if(i >= 1 && (temp[i].value == temp[i-1].value)) {
        temp[i].order = temp[i-1].order;
      }else{
        temp[i].order = i;
      }
    }

    for(int i=0; i<batchsize; i++){
      int64_t test = data[n][startLine + i];
      OrderMatrix[n][i].value = test;
      for(int j=0; j<batchsize; j++){
        if(temp[j].value == OrderMatrix[n][i].value) {
          OrderMatrix[n][i].order = temp[j].order;
          break;
        }
      }
    }
  }

  // 判断列之间的正负相关关系
  std::vector<double> relativeRelationship(colNum);
  for(int i=0; i<colNum; i++){
    relativeRelationship[i] = corr(OrderMatrix[i], OrderMatrix[0], batchsize);
  }
  //负相关则order转向
  valid->push_back(true);
  for(int i=1; i<colNum; i++){
    if(relativeRelationship[i] < 0.5 && relativeRelationship[i]>-0.5){
      valid->push_back(false);
    }else{
      valid->push_back(true);
      if(relativeRelationship[i] < 0){
        for(int j=0; j<batchsize; j++){
          OrderMatrix[i][j].order = batchsize-1 - OrderMatrix[i][j].order;
        }
      }
    }

  }

  //统计优先级
  std::vector<PriorityRecorder> priority(batchsize);
  for(int j=0; j < batchsize; j++){
    priority[j].oldOrder = j;
  }
  for(int j=0; j < batchsize; j++){
    for(int i=0; i<colNum; i++){
      if(valid->at(i)){
        priority[j].priority += OrderMatrix[i][j].order;
      }
    }
  }
  // 优先级排序
  std::sort(priority.begin(), priority.end(), PriComparor);

  std::vector<std::vector<int64_t>> result(colNum);
  for(int i=0; i<colNum; i++){
    for(int j=0; j < batchsize; j++){
      result[i].push_back(0);
    }
  }

//  printf("new\n");
  for(int j=0; j<batchsize; j++){
    int oldOrder = priority[j].oldOrder;
    for(int i=0; i<colNum; i++){
      result[i][j] = data[i][startLine + oldOrder];
//      printf("%ld ", result[i][j]);
    }
//    printf("\n");
  }

  return result;
}

int Column_Reorder(SequenceStruct* col, int length, LinearPara linearPara, ReorderResult* minMaxResult){
  int64_t realValue = col[0].value;
  int64_t predictValue = col[0].order * linearPara.para_k + linearPara.para_b;
  int64_t linearDelta = realValue - predictValue;
  int deltaMin = linearDelta, deltaMax = linearDelta;
  int directMin = col[0].value, directMax = col[0].value;

  for(int j=1; j<length; j++){
    realValue = col[j].value;
    predictValue = col[j].order * linearPara.para_k + linearPara.para_b;
    linearDelta = realValue - predictValue;
    if(deltaMin > linearDelta) deltaMin = linearDelta;
    if(deltaMax < linearDelta) deltaMax = linearDelta;

    if(directMin > col[j].value) directMin = col[j].value;
    if(directMin < col[j].value) directMax = col[j].value;

    int ll = 0;
    while(true){
      if((linearDelta >> ll) != 0){
        ll++;
      }else{
        break;
      }
    }
    minMaxResult->linearLevels.push_back(ll);
  }

  uint64_t delta = deltaMax - deltaMin;
  int level = 0;
  while(true){
    if((delta >> level) != 0){
      level++;
    }else{
      break;
    }
  }
  minMaxResult->maxLength = level;

  delta = directMax - directMin;
  level = 0;
  while(true){
    if((delta >> level) != 0){
      level++;
    }else{
      break;
    }
  }
  minMaxResult->directMaxLength = level;

  for(int i=0; i<length; i++){
    realValue = col[i].value;
    predictValue = col[i].order * linearPara.para_k + linearPara.para_b;
    linearDelta = realValue - predictValue;
    minMaxResult->linearValues.push_back(linearDelta - deltaMin);
    minMaxResult->orders.push_back(col[i].order);
    minMaxResult->directValues.push_back(realValue-directMin);
  }
  minMaxResult->linearMin = deltaMin;
  minMaxResult->directMin = directMin;

  return 0;
}

std::vector<ReorderResult>
BatchReorder_New(const std::vector<std::vector<int64_t>> &data, uint64_t startLine, int batchsize, int colNum) {
  std::vector<ReorderResult> result;

  for(int n = 0; n<colNum; n++){
    ReorderResult tempResult;

    std::vector<SequenceStruct> temp(batchsize);
    // 构造序数表
    for(int i=0; i<batchsize; i++){
      temp[i].value = data[n][startLine + i];
    }

    std::sort(temp.begin(), temp.end(), SeqComparor);

    int64_t mMax = (temp.cbegin()->value);
    int64_t mMin = (temp.begin()->value);
    int EqualSize = (mMax - mMin) * EqualRatio;

    std::vector<int64_t> linearVector;
    int startOrder = 0;
    for(int i=0; i<batchsize; i++){
      if(i >= 1 && (temp[i].value - temp[i-1].value < EqualSize)) {
        temp[i].order = temp[i-1].order;
      }else{
        temp[i].order = startOrder;
        startOrder++;
        linearVector.push_back(temp[i].value);
      }
    }

    LinearSolver2 linearSolver2(linearVector.size(), linearVector.data());
    float k = linearSolver2.getK();
    float b = linearSolver2.getB();
    tempResult.paras = {k, b};
    tempResult.maxOrder = startOrder;

    Column_Reorder(temp.data(), batchsize, {k, b}, &tempResult);
  }

  return result;
}


#endif //SIMBASEDREORDER_BATCHREORDER_H
