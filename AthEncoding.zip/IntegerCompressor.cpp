//
// Created by Borelset on 2023/7/3.
//

#include <iostream>
#include <fstream>
#include <set>
#include "gflags/gflags.h"
#include "rapidcsv.h"
#include "varint/varint.h"
#include "lz4-1.9.4/lib/lz4.h"

#include "LinearSolver.h"
#include "BatchReorder.h"


DEFINE_string(InputFile, "", "batch process file path");
DEFINE_int32(BatchSize, 20, "batch size");
DEFINE_string(Columns, "", "batch process file path");


struct CompressionResult{
    int Raw = 0, LZ4 = 0;
    int Linear = 0, MinMax = 0;

};

std::vector<std::vector<int64_t>> shuffle(const std::vector<std::vector<int64_t>>& data){
  auto col = data.begin();
  int rows = col->size();
  int cols = data.size();

  std::vector<std::vector<int64_t>> result(cols);
  for(int i=0; i<cols; i++){
    for(int j=0; j < rows; j++){
      result[i].push_back(0);
    }
  }

  srand(0);

  for(int i=0; i<rows; i++){
    int newRow = rand()%rows;
    for(int j=0; j<cols; j++){
      result[j][newRow] = data[j][i];
      result[j][i] = data[j][newRow];
    }
  }

  return result;
}

CompressionResult operator+(const CompressionResult& lp, const CompressionResult& rp){
  CompressionResult compressionResult;
  compressionResult.Raw = lp.Raw + rp.Raw;
  compressionResult.LZ4 = lp.LZ4 + rp.LZ4;
  compressionResult.MinMax = lp.MinMax + rp.MinMax;
  compressionResult.Linear = lp.Linear + rp.Linear;
  return compressionResult;
}

struct LinearResult{
    std::vector<int64_t> deltas;
    LinearPara linearPara;
};

struct MinMaxResult{
    std::vector<uint64_t> values;
    int min;
    int valueLength;
    std::vector<int> orders;
};

std::string MinMaxResultToString(const std::vector<MinMaxResult>& data, uint64_t startLine, int batchsize, int colNum){
  std::string result;
  char buffer[8];

  for(int i=0; i<colNum; i++){
    memcpy(buffer, &data[i].min, sizeof(data[i].min));
    result.append(buffer, sizeof(data[i].min));
  }

  for(int j=0; j<batchsize; j++){
    for(int i=0; i<colNum; i++){
      memcpy(buffer, &data[i].values[j+startLine], data[i].valueLength);
      result.append(buffer, data[i].valueLength);
    }
  }
  return result;
}

std::string MinMaxLinearResultToString(const std::vector<MinMaxResult>& data, const std::vector<LinearPara>& paras, uint64_t startLine, int batchsize, int colNum){
  std::string result;
  char buffer[8];

  for(int i=0; i<colNum; i++){
    memcpy(buffer, &paras[i], sizeof(paras[i]));
    result.append(buffer, sizeof(paras[i]));
  }

  for(int i=0; i<colNum; i++){
    memcpy(buffer, &data[i].min, sizeof(data[i].min));
    result.append(buffer, sizeof(data[i].min));
  }

  for(int j=0; j<batchsize; j++){
    for(int i=0; i<colNum; i++){
      memcpy(buffer, &data[i].values[j+startLine], data[i].valueLength);
      result.append(buffer, data[i].valueLength);
    }
  }
  return result;
}

std::set<int> parser(std::string& columns){
  std::set<int> result;
  std::string leftStr = columns;
  while(leftStr.size() != 0){
    std::size_t pos = leftStr.find(',');
    if(pos == std::string::npos){
      int colNumber = std::stoi(leftStr);
      result.insert(colNumber);
      break;
    }else{
      std::string numberStr = leftStr.substr(0, pos);
      int colNumber = std::stoi(numberStr);
      result.insert(colNumber);
      leftStr = leftStr.substr(pos+1);
    }
  }

  return result;
}

int Column_MinMax(int64_t* col, int length, MinMaxResult* minMaxResult){
  int min = col[0], max = col[0];
  for(int j=1; j<length; j++){
    if(min > col[j]) min = col[j];
    if(max < col[j]) max = col[j];
  }
  uint64_t delta = max - min;
  int level = 0;

  while(true){
    if((delta >> level) != 0){
      level++;
    }else{
      break;
    }
  }

  minMaxResult->valueLength = level/8;
  int bits = level % 8;
  if(bits != 0){
    minMaxResult->valueLength++;
  }
  if(minMaxResult->valueLength == 0) minMaxResult->valueLength = 1;

  for(int i=0; i<length; i++){
    minMaxResult->values.push_back(col[i]-min);
  }
  minMaxResult->min = min;

  return 0;
}

LinearResult LinearConvert(int num, const int64_t *list){
  LinearSolver2 linearSolver(num, list);
  float k = linearSolver.getK();
  float b = linearSolver.getB();

  LinearResult result;
  for(int i=0; i<num; i++){
    int predict = lround(k * i + b);
    int delta = list[i] - predict;
    result.deltas.push_back(delta);
  }
  result.linearPara.para_k = k;
  result.linearPara.para_b = b;

  return result;
}

CompressionResult MinMax_Compression(const std::vector<std::vector<int64_t>>& data, uint64_t startLine, int colNum){
  int batchsize = 0;
  int leftLines = data.begin()->size() - startLine;
  if(leftLines < FLAGS_BatchSize){
    batchsize = leftLines;
  }else{
    batchsize = FLAGS_BatchSize;
  }

  std::vector<MinMaxResult> MinMaxList;

  for(auto item : data){
    MinMaxResult minMaxResult;
    int r = Column_MinMax(&item[startLine], batchsize, &minMaxResult);
    MinMaxList.push_back(minMaxResult);
  }

  CompressionResult compressionResult;

  for(int i=0; i<colNum; i++){
    compressionResult.Raw += batchsize * MinMaxList[i].valueLength;
    compressionResult.MinMax += sizeof(MinMaxList[i].min);
  }

//  char* buffer = (char*)malloc(8192);
//  std::string str = MinMaxResultToString(MinMaxList, startLine, batchsize, colNum);
//  compressionResult.LZ4 = LZ4_compress_default(str.data(), buffer, str.size(), 8192);
//  assert(compressionResult.LZ4 != 0);
//  free(buffer);

  return compressionResult;
}

CompressionResult ReorderLinear_New_Compression(const std::vector<std::vector<int64_t>>& data, uint64_t startLine, int colNum){
  int batchsize = 0;
  int leftLines = data.begin()->size() - startLine;
  if(leftLines < FLAGS_BatchSize){
    batchsize = leftLines;
  }else{
    batchsize = FLAGS_BatchSize;
  }

  std::vector<ReorderResult> MinMaxList = BatchReorder_New(data, startLine, batchsize, colNum);
  std::string str = ReorderResultToString(MinMaxList, batchsize, colNum);

  CompressionResult compressionResult;

  compressionResult.Raw = str.size();

  return compressionResult;
}

CompressionResult MinMax_Linear_Compression(const std::vector<std::vector<int64_t>>& data, uint64_t startLine, int colNum){
  std::vector<std::vector<uint64_t>> result;

  int batchsize = 0;
  int leftLines = data.begin()->size() - startLine;
  if(leftLines < FLAGS_BatchSize){
    batchsize = leftLines;
  }else{
    batchsize = FLAGS_BatchSize;
  }

  std::vector<MinMaxResult> MinMaxList;
  std::vector<LinearPara> LinearParaList;

  for(auto item : data){
    LinearResult linearResult = LinearConvert(batchsize, &item[startLine]);
    MinMaxResult minMaxResult;
    int r = Column_MinMax(linearResult.deltas.data(), batchsize, &minMaxResult);
    MinMaxList.push_back(minMaxResult);
    LinearParaList.push_back(linearResult.linearPara);
  }

  CompressionResult compressionResult;
  for(int i=0; i<colNum; i++){
    compressionResult.Raw += batchsize * MinMaxList[i].valueLength;
  }

  for(int i=0; i<MinMaxList.size(); i++){
    compressionResult.MinMax += sizeof(MinMaxList[i].min);
  }

  for(int i=0; i<LinearParaList.size(); i++){
    compressionResult.Linear += sizeof(LinearParaList[i].para_b) + sizeof(LinearParaList[i].para_k);
  }

  char* buffer = (char*)malloc(8192);
  std::string str = MinMaxLinearResultToString(MinMaxList, LinearParaList, startLine, batchsize, colNum);
  compressionResult.LZ4 = LZ4_compress_default(str.data(), buffer, str.size(), 8192);
  assert(compressionResult.LZ4 != 0);
  free(buffer);

  return compressionResult;
}

CompressionResult MinMax_Reorder_Linear_Compression(const std::vector<std::vector<int64_t>>& data, uint64_t startLine, int colNum){
  std::vector<std::vector<uint64_t>> result;

  int batchsize = 0;
  int leftLines = data.begin()->size() - startLine;
  if(leftLines < FLAGS_BatchSize){
    batchsize = leftLines;
  }else{
    batchsize = FLAGS_BatchSize;
  }

  std::vector<MinMaxResult> MinMaxList;
  std::vector<LinearPara> LinearParaList;

  auto batchReordered = BatchReorder(data, startLine, batchsize, colNum);
  for(auto item : batchReordered){
    LinearResult linearResult = LinearConvert(batchsize, &item[0]);
    MinMaxResult minMaxResult;
    int r = Column_MinMax(linearResult.deltas.data(), batchsize, &minMaxResult);
    MinMaxList.push_back(minMaxResult);
    LinearParaList.push_back(linearResult.linearPara);
  }

  CompressionResult compressionResult;
  for(int i=0; i<colNum; i++){
    compressionResult.Raw += batchsize * MinMaxList[i].valueLength;
  }

  for(int i=0; i<MinMaxList.size(); i++){
    compressionResult.MinMax += sizeof(MinMaxList[i].min);
  }

  for(int i=0; i<LinearParaList.size(); i++){
    compressionResult.Linear += sizeof(LinearParaList[i].para_b) + sizeof(LinearParaList[i].para_k);
  }


  char* buffer = (char*)malloc(8192);
  std::string str = MinMaxLinearResultToString(MinMaxList, LinearParaList, startLine, batchsize, colNum);
  compressionResult.LZ4 = LZ4_compress_default(str.data(), buffer, str.size(), 8192);
  assert(compressionResult.LZ4 != 0);
  free(buffer);

  return compressionResult;
}

CompressionResult MinMax_Reorder_Linear_Compression2(const std::vector<std::vector<int64_t>>& data, uint64_t startLine, int colNum){
  std::vector<std::vector<uint64_t>> result;

  int batchsize = 0;
  int leftLines = data.begin()->size() - startLine;
  if(leftLines < FLAGS_BatchSize){
    batchsize = leftLines;
  }else{
    batchsize = FLAGS_BatchSize;
  }

  std::vector<MinMaxResult> MinMaxList;
  std::vector<LinearPara> LinearParaList;
  std::vector<bool> valid;
  int counter = 0;

  auto batchReordered = BatchReorder2(data, startLine, batchsize, colNum, &valid);
  for(auto item : batchReordered){
    if(valid[counter]){
      LinearResult linearResult = LinearConvert(batchsize, &item[0]);
      MinMaxResult minMaxResult;
      int r = Column_MinMax(linearResult.deltas.data(), batchsize, &minMaxResult);
      MinMaxList.push_back(minMaxResult);
      LinearParaList.push_back(linearResult.linearPara);
    }else{
      MinMaxResult minMaxResult;
      int r = Column_MinMax(item.data(), batchsize, &minMaxResult);
      MinMaxList.push_back(minMaxResult);
    }
    counter++;
  }

  CompressionResult compressionResult;
  for(int i=0; i<colNum; i++){
    compressionResult.Raw += batchsize * MinMaxList[i].valueLength;
  }

  for(int i=0; i<MinMaxList.size(); i++){
    compressionResult.MinMax += sizeof(MinMaxList[i].min);
  }

  for(int i=0; i<LinearParaList.size(); i++){
    compressionResult.Linear += sizeof(LinearParaList[i].para_b) + sizeof(LinearParaList[i].para_k);
  }


  char* buffer = (char*)malloc(8192);
  std::string str = MinMaxLinearResultToString(MinMaxList, LinearParaList, startLine, batchsize, colNum);
  compressionResult.LZ4 = LZ4_compress_default(str.data(), buffer, str.size(), 8192);
  assert(compressionResult.LZ4 != 0);
  free(buffer);

  return compressionResult;
}

CompressionResult MinMax_Reorder_Linear_New_Compression(const std::vector<std::vector<int64_t>>& data, uint64_t startLine, int colNum){
  std::vector<std::vector<uint64_t>> result;

  int batchsize = 0;
  int leftLines = data.begin()->size() - startLine;
  if(leftLines < FLAGS_BatchSize){
    batchsize = leftLines;
  }else{
    batchsize = FLAGS_BatchSize;
  }

  std::vector<MinMaxResult> MinMaxList;
  std::vector<LinearPara> LinearParaList;
  std::vector<bool> valid;
  int counter = 0;

  auto batchReordered = BatchReorder2(data, startLine, batchsize, colNum, &valid);
  for(auto item : batchReordered){
    if(valid[counter]){
      LinearResult linearResult = LinearConvert(batchsize, &item[0]);
      MinMaxResult minMaxResult;
      int r = Column_MinMax(linearResult.deltas.data(), batchsize, &minMaxResult);
      MinMaxList.push_back(minMaxResult);
      LinearParaList.push_back(linearResult.linearPara);
    }else{
      MinMaxResult minMaxResult;
      int r = Column_MinMax(item.data(), batchsize, &minMaxResult);
      MinMaxList.push_back(minMaxResult);
    }
    counter++;
  }

  CompressionResult compressionResult;
  for(int i=0; i<colNum; i++){
    compressionResult.Raw += batchsize * MinMaxList[i].valueLength;
  }

  for(int i=0; i<MinMaxList.size(); i++){
    compressionResult.MinMax += sizeof(MinMaxList[i].min);
  }

  for(int i=0; i<LinearParaList.size(); i++){
    compressionResult.Linear += sizeof(LinearParaList[i].para_b) + sizeof(LinearParaList[i].para_k);
  }


  char* buffer = (char*)malloc(8192);
  std::string str = MinMaxLinearResultToString(MinMaxList, LinearParaList, startLine, batchsize, colNum);
  compressionResult.LZ4 = LZ4_compress_default(str.data(), buffer, str.size(), 8192);
  assert(compressionResult.LZ4 != 0);
  free(buffer);

  return compressionResult;
}

CompressionResult MinMax_Reorder_Compression(const std::vector<std::vector<int64_t>>& data, uint64_t startLine, int colNum){

  int batchsize = 0;
  int leftLines = data.begin()->size() - startLine;
  if(leftLines < FLAGS_BatchSize){
    batchsize = leftLines;
  }else{
    batchsize = FLAGS_BatchSize;
  }

  std::vector<MinMaxResult> MinMaxList;

  auto batchReordered = BatchReorder(data, startLine, batchsize, colNum);
  for(auto item : batchReordered){
    MinMaxResult minMaxResult;
    int r = Column_MinMax(item.data(), batchsize, &minMaxResult);
    MinMaxList.push_back(minMaxResult);
  }

  CompressionResult compressionResult;
  for(int i=0; i<colNum; i++){
    compressionResult.Raw += batchsize * MinMaxList[i].valueLength;
    compressionResult.MinMax += sizeof(MinMaxList[i].min);
  }

  char* buffer = (char*)malloc(8192);
  std::string str = MinMaxResultToString(MinMaxList, startLine, batchsize, colNum);
  compressionResult.LZ4 = LZ4_compress_default(str.data(), buffer, str.size(), 8192);
  assert(compressionResult.LZ4 != 0);
  free(buffer);

  return compressionResult;
}

int main(int argc, char **argv) {

  gflags::ParseCommandLineFlags(&argc, &argv, true);
  std::cout << "Batch path: " << FLAGS_InputFile << std::endl;

  std::set<int> colNumbers = parser(FLAGS_Columns);

  rapidcsv::Document doc(FLAGS_InputFile);

  std::vector<std::vector<int64_t>> data;

  for(auto item : colNumbers){
    std::vector<int64_t> col = doc.GetColumn<int64_t>(item);
    data.push_back(col);
  }

  data = shuffle(data);

  uint64_t count = data.begin()->size();
  uint64_t batchNum = count/FLAGS_BatchSize;

  CompressionResult MinMax, MinMax_Linear, MinMax_Reorder_Linear, MinMax_Reorder;

  for(int i=0; i<batchNum; i++){
    MinMax = MinMax + MinMax_Compression(data, i*FLAGS_BatchSize, data.size());
//    MinMax_Linear = MinMax_Linear + MinMax_Linear_Compression(data, i*FLAGS_BatchSize, data.size());
//    MinMax_Reorder_Linear = MinMax_Reorder_Linear + MinMax_Reorder_Linear_Compression2(data, i*FLAGS_BatchSize, data.size());
//    MinMax_Reorder = MinMax_Reorder + MinMax_Reorder_Compression(data, i*FLAGS_BatchSize, data.size());
    MinMax_Reorder_Linear = MinMax_Reorder_Linear + ReorderLinear_New_Compression(data, i*FLAGS_BatchSize, data.size());
  }

  printf("Raw => MinMax:%d + %d, MinMax_Linear:%d + %d + %d, MinMax_Reorder_Linear:%d + %d + %d, MinMax_Reorder:%d + %d\n",
         MinMax.Raw, MinMax.MinMax,
         MinMax_Linear.Raw, MinMax_Linear.MinMax, MinMax_Linear.Linear,
         MinMax_Reorder_Linear.Raw, MinMax_Reorder_Linear.MinMax, MinMax_Reorder_Linear.Linear,
         MinMax_Reorder.Raw, MinMax_Reorder.MinMax);
  printf("LZ4 => MinMax:%d, MinMax_Linear:%d, MinMax_Reorder_Linear:%d, MinMax_Reorder:%d\n",
         MinMax.LZ4, MinMax_Linear.LZ4, MinMax_Reorder_Linear.LZ4, MinMax_Reorder.LZ4);

}
