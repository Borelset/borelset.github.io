//
// Created by Borelset on 2023/7/13.
//

#include <iostream>
#include <fstream>
#include <set>
#include "IntegerConvertor.h"
#include "gflags/gflags.h"
#include "rapidcsv.h"
#include "FileOperator.h"
#include "AthCompressor.h"

DEFINE_string(InputFile, "", "batch process file path");
DEFINE_int32(BatchSize, 20, "batch size");
DEFINE_string(Columns, "", "batch process file path");

std::set<int> parser(std::string& columns){
  std::set<int> result;
  std::string leftStr = columns;
  while(leftStr.size() != 0){
    std::size_t pos = leftStr.find(',');
    if(pos == std::string::npos){
      int colNumber = std::stoi(leftStr);
      result.insert(colNumber);
      break;
    }else{
      std::string numberStr = leftStr.substr(0, pos);
      int colNumber = std::stoi(numberStr);
      result.insert(colNumber);
      leftStr = leftStr.substr(pos+1);
    }
  }

  return result;
}

int main(int argc, char **argv) {

  gflags::ParseCommandLineFlags(&argc, &argv, true);
  std::cout << "Batch path: " << FLAGS_InputFile << std::endl;

  std::set<int> colNumbers = parser(FLAGS_Columns);

  rapidcsv::Document doc(FLAGS_InputFile);

  std::vector<std::vector<int64_t>> data;

//  for (auto item: colNumbers) {
//    std::vector<float> col = doc.GetColumn<float>(item);
//    std::vector<int64_t> convert;
//    for(int i=0; i<col.size(); i++){
//      convert.push_back(col[i]*100);
//    }
//    data.push_back(convert);
//  }

  for (auto item: colNumbers) {
    std::vector<int64_t> col = doc.GetColumn<int64_t>(item);
    data.push_back(col);
  }

  uint64_t count = data.begin()->size();
  uint64_t batchNum = count/FLAGS_BatchSize;
  uint64_t newLength = 0, oldLength = 0;

//  FileOperator fo("test", FileOpenType::ReadWrite);

  ComData comDataTotal;
  for(int i=0; i<batchNum; i++){
    for(int j=0; j<colNumbers.size(); j++){
      AthCompressor athCompressor;
      for(int k=0; k<FLAGS_BatchSize; k++){
        int index = i*FLAGS_BatchSize + k;
        if(index >= count) break;
        athCompressor.addData(data[j][index]);
      }
      std::string result;
      ComData comData = athCompressor.compress(&result);
      comDataTotal = comDataTotal + comData;

      int ratio = athCompressor.getRatio();
      int datumLength = athCompressor.getDatumLength();

      if(athCompressor.getValid()){
        uint8_t* ptr = (uint8_t*)result.data();
        ptr += sizeof(uint8_t);
        ptr += sizeof(int64_t);
        for(int k=0; k<FLAGS_BatchSize; k++){
          int index = i*FLAGS_BatchSize + k;
          if(index >= count) break;

          DecodeOutput decodeOutput = AthDecoding(ptr, datumLength, ratio);
          ptr += decodeOutput.usedLength;
          uint64_t value = 0;
          memcpy(&value, decodeOutput.output, decodeOutput.length);
          int64_t recover = athCompressor.getDeltaMin();
          recover += value;
//          if(recover != data[j][index]) printf("#%d %ld => %ld\n", k, data[j][index], recover);
        }
      }
    }
  }

  printf("Raw => OldLength:%lu, NewLength:%lu\n", comDataTotal.naive, comDataTotal.ath);
}