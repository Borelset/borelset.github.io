//
// Created by Borelset on 2022/6/29.
//

#ifndef FDISTRIBUTIONSOLVER_H
#define FDISTRIBUTIONSOLVER_H

#include <malloc.h>
#include <list>
#include <algorithm>
#include <functional>
#include <cmath>

#define QUANTIZATION_GRID_NUMBER 100
#define PI (3.1415926)
#define STOPTHRESHOLD (0.00001)
#define LEARNINGRATE (0.02)
#define Beta1 (0.8)
#define Beta2 (0.95)
#define Eta (0.05)
#define Epsilon (1e-8)
#define DECAYSTEP 100
#define DECAYRATE (0.05)
#define STOPSEGMENT (20)

class LinearSolver {
public:
    LinearSolver(int num, const int64_t *list) : para_k(0.7), para_b(1.0), dataNumber(num) {

      double *predictValues = (double *) malloc(sizeof(double) * dataNumber);
      double *loss = (double *) malloc(sizeof(double) * dataNumber);

      while (1) {
        for (int i = 0; i < dataNumber; i++) {
          predictValues[i] = para_b * i + para_k;
        }
        for (int i = 0; i < dataNumber; i++) {
          loss[i] = (double)list[i] - predictValues[i];
        }

        double totalLoss = 0.0;
        for (int i = 0; i <= dataNumber; i++) {
          totalLoss += loss[i] * loss[i];
        }

        printf("Round %d...\n", round+1);
        printf("para_k=%f, para_b=%f, loss=%e\n", para_k, para_b, totalLoss);
        round++;

        lastLoss.push_back(totalLoss);
        if (lastLoss.size() > STOPSEGMENT) lastLoss.pop_front();
        double max = *lastLoss.begin(), min = *lastLoss.begin();
        for (auto item: lastLoss) {
          if (item > max) max = item;
          if (item < min) min = item;
        }

        if (lastLoss.size() >= STOPSEGMENT && max / min - 1 < STOPTHRESHOLD) {
          finalLoss = totalLoss;
          break;
        }

        double gradPara_k = 0.0, gradPara_b = 0.0;

        for (int i = 0; i <= dataNumber; i++) {
          gradPara_k += 2.0 * ((double)list[i] - predictValues[i]) * (-i);
          gradPara_b += 2.0 * ((double)list[i] - predictValues[i]) * (-1);
        }

        mTpara_k = Beta1 * mTpara_k + (1 - Beta1) * gradPara_k;
        mTpara_b = Beta1 * mTpara_b + (1 - Beta1) * gradPara_b;
        vTpara_k = Beta2 * vTpara_k + (1 - Beta2) * pow(gradPara_k, 2);
        vTpara_b = Beta2 * vTpara_b + (1 - Beta2) * pow(gradPara_b, 2);

        double mTpara_k_temp = mTpara_k / (1 - pow(Beta1, round));
        double mTpara_b_temp = mTpara_b / (1 - pow(Beta1, round));
        double vTpara_k_temp = vTpara_k / (1 - pow(Beta2, round));
        double vTpara_b_temp = vTpara_b / (1 - pow(Beta2, round));

        para_k += mTpara_k_temp * (Eta / (sqrt(vTpara_k_temp) + Epsilon)) * LEARNINGRATE * exp(-DECAYRATE * round / DECAYSTEP);
        para_b += mTpara_b_temp * (Eta / (sqrt(vTpara_b_temp) + Epsilon)) * LEARNINGRATE *
                 exp(-DECAYRATE * round / DECAYSTEP);
      }


      printf("para_k=%f, para_b=%f, loss=%e\n", para_k, para_b, finalLoss);

      free(predictValues);
      free(loss);
    }

    ~LinearSolver() {
    }

    double getK(){
      return para_k;
    }

    double getB(){
      return para_b;
    }

private:
    double para_k, para_b;
    double finalLoss;
    int dataNumber;
    uint64_t round = 0;
    std::list<double> lastLoss;
    double mTpara_k = 0.0, mTpara_b = 0.0, vTpara_k = 0.0, vTpara_b = 0.0;
};

class LinearSolver2 {
public:
    LinearSolver2(int num, const int64_t *list) : dataNumber(num){
      double sumx2 = 0.0, sumxy = 0.0, sumx = 0.0, sumy = 0.0;
      for(int i=0; i<dataNumber; i++){
        sumx2 += (double)i * i;
        sumxy += (double)list[i] * i;
        sumx  += (double)i;
        sumy  += (double)list[i];
      }

      para_k = (dataNumber * sumxy - sumx * sumy) / (dataNumber * sumx2 - sumx * sumx);
      para_b = sumy/dataNumber - para_k * sumx / dataNumber;
    }

    double getK(){
      return para_k;
    }

    double getB(){
      return para_b;
    }
private:
    int dataNumber;
    double para_k, para_b;
};

#endif //FDISTRIBUTIONSOLVER_H
