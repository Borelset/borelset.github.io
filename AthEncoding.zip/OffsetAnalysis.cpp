//
// Created by Borelset on 2023/6/25.
//

#include <iostream>
#include <fstream>
#include "gflags/gflags.h"
#include <unordered_map>
#include <unordered_set>
#include <set>
#include <algorithm>
#include <list>
#include <map>
#include "Odess.h"
#include "FileOperator.h"
#include "lz4-1.9.4/lib/lz4.h"

DEFINE_string(InputFile, "", "batch process file path");
DEFINE_double(LowerLimit, 0.1, "");
DEFINE_double(UpperLimit, 0.3, "");

using std::string;

struct Offset{
    int offset;
    int length;
};

int main(int argc, char **argv) {
  gflags::ParseCommandLineFlags(&argc, &argv, true);
  std::ifstream infile;
  infile.open(FLAGS_InputFile);
  std::string rowData;
  std::cout << "Batch path: " << FLAGS_InputFile << std::endl;

  std::list<Offset> olist;

  while (std::getline(infile, rowData)) {
    size_t pos = rowData.find(',');
    string off = rowData.substr(0, pos);
    string len = rowData.substr(pos+1);
    olist.push_back({std::stoi(off), std::stoi(len)});
  }

  int max = 0, min = INT32_MAX;
  for(auto item : olist){
    if(item.offset < min) min = item.offset;
    if(item.offset > max) max = item.offset;
  }

  std::map<int, int> recorder;
  for(int i=0; i<=max; i++){
    recorder[i] = 0;
  }

  for(auto item : olist){
    for(int i=0; i<item.length; i++){
      int startOffset = item.offset;
      recorder[startOffset+i]++;
    }
  }

  for(auto item : recorder){
    printf("#%d = %d\n", item.first, item.second);
  }

  printf("output:\n");
  int lower = olist.size()*FLAGS_LowerLimit, upper = olist.size()*FLAGS_UpperLimit;
  for(auto item: recorder){
    if(item.second > lower && item.second < upper)
      printf("%d, ", item.first);
  }
  printf("==================================\n");
}