//
// Created by Borelset on 2023/6/26.
//

#ifndef SIMBASEDREORDER_OFFSETLIST_H
#define SIMBASEDREORDER_OFFSETLIST_H

#include <list>
#include <map>

DEFINE_double(LowerLimit, 0.1, "");
DEFINE_double(UpperLimit, 0.3, "");

using std::string;

struct Offset{
    int offset;
    int length;
};

std::set<int> getAllowList(std::string OffsetFile){
  std::ifstream infile;
  infile.open(OffsetFile);
  std::string rowData;
  std::cout << "Offset path: " << OffsetFile << std::endl;
  printf("LowerLimit: %f, UpperLimit: %f\n", FLAGS_LowerLimit, FLAGS_UpperLimit);

  std::list<Offset> olist;

  while (std::getline(infile, rowData)) {
    size_t pos = rowData.find(',');
    string off = rowData.substr(0, pos);
    string len = rowData.substr(pos+1);
    olist.push_back({std::stoi(off), std::stoi(len)});
  }

  int max = 0, min = INT32_MAX;
  for(auto item : olist){
    if(item.offset < min) min = item.offset;
    if(item.offset > max) max = item.offset;
  }

  std::map<int, int> recorder;
  for(int i=0; i<=max; i++){
    recorder[i] = 0;
  }

  for(auto item : olist){
    for(int i=0; i<item.length; i++){
      int startOffset = item.offset;
      recorder[startOffset+i]++;
    }
  }


  uint64_t maxCounter = 0;
  for(auto item: recorder){
    if(item.second > maxCounter) maxCounter = item.second;
  }

//  for(auto item : recorder){
//    printf("#%d = %d\n", item.first, item.second);
//  }

  std::set<int> result;

  printf("allow list\n");
  int lower = maxCounter * FLAGS_LowerLimit, upper = maxCounter * FLAGS_UpperLimit;
  for(auto item: recorder){
    if(item.second > lower && item.second < upper){
      printf("%d, ", item.first);
      result.insert(item.first);
    }
  }
  printf("\n");

  return result;
}

#endif //SIMBASEDREORDER_OFFSETLIST_H
