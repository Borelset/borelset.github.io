//
// Created by Borelset on 2023/6/5.
//

#ifndef SIMBASEDREORDER_REORDER_H
#define SIMBASEDREORDER_REORDER_H

#include "unordered_map"

//                   index    Entry
std::unordered_map<uint64_t, Entry> rawData;
//                  feature    index set
std::unordered_map<uint64_t, std::unordered_set<uint64_t>> fl[SuperFeatureNum];

struct RecordingEntry{
    int idx;
    uint64_t value;
    uint64_t count;
};

bool RecordingEntryCmp(const RecordingEntry &lhs, const RecordingEntry &rhs) {
  return lhs.count > rhs.count;
}

std::vector<RecordingEntry> recordingList;

void removeItem(uint64_t id){
  auto iditem = rawData.find(id);
  assert(iditem != rawData.end());
  Feature& tmpf = iditem->second.ft;

  for(int i=0; i<SuperFeatureNum; i++){
    uint64_t tmpff = tmpf.ff[i];
    auto iter = fl[i][tmpff].find(id);
    assert(iter != fl[i][tmpff].end());
    fl[i][tmpff].erase(iter);

    auto iterSet = fl[i].find(tmpff);
    if(iterSet->second.empty()){
      fl[i].erase(iterSet);
    }
  }

  rawData.erase(iditem);
}

std::vector<Entry> reorder(std::vector<Entry>& data){
  uint64_t counter = 0;
  for(auto item: data){
    rawData[counter] = item;
    for(int i = 0; i<SuperFeatureNum; i++){
      fl[i][item.ft.ff[i]].insert(counter);
    }
    counter++;
  }
  printf("Reorder Init.. \n");

  std::vector<Entry> result;

  uint64_t fc = 0, processed = 0;
  int previousMax = 0;
  for(int i=0; i<SuperFeatureNum; i++){
    for(auto item: fl[i]){
      recordingList.push_back({i, item.first, item.second.size()});
    }
  }
  std::sort(recordingList.begin(), recordingList.end(), RecordingEntryCmp);
  for(auto item: recordingList){
    auto targetSet = fl[item.idx][item.value];
    for(auto id: targetSet){
      result.push_back(rawData[id]);
      removeItem(id);
    }
    processed += targetSet.size();
    if(fc <= 9){
      printf("Family #%lu: %lu items, processed: %lu / %lu\n", fc, targetSet.size(), processed, counter);
    }
    fc++;
    if(processed >= counter) break;
  }

  int cc = 0;
  std::vector<Entry>::iterator start, end;
  for(auto iner = result.begin(); iner != result.end(); iner++){
    if(cc % FLAGS_BatchSize == 0){
      start = iner;
    }
    if(cc % FLAGS_BatchSize == FLAGS_BatchSize-1 || cc == result.size()-1){
      end = iner;
      std::sort(start, end, EntryComparor);
    }
    cc++;
  }

  return result;
}

void shuffle(std::vector<Entry>& data){
  uint64_t counter = 0;
  for(auto item: data){
    counter++;
  }
  printf("Shuffle Init.. \n");

  srand(0);

  for(int i=0; i<counter; i++){
    int newIndex = rand()%counter;
    auto temp = data[i];
    data[i] = data[newIndex];
    data[newIndex] = temp;
  }

  return;
}

#endif //SIMBASEDREORDER_REORDER_H
