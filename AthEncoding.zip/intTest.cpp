//
// Created by Borelset on 2023/6/19.
//

#include <iostream>
#include <fstream>
#include <set>
#include "gflags/gflags.h"
#include "rapidcsv.h"
#include "LinearSolver.h"
#include "BatchReorder.h"
#include "varint/varint.h"
#include "lz4-1.9.4/lib/lz4.h"

DEFINE_string(InputFile, "", "batch process file path");
DEFINE_int32(BatchSize, 20, "batch size");
DEFINE_string(Columns, "", "batch process file path");


struct Line{
    int* values;
};

std::string ArrayToString(const std::vector<std::vector<int64_t>>& data, uint64_t startLine, int batchsize, int colNum){
  std::string result;
  char buffer[8];

  for(int j=0; j<batchsize; j++){
    for(int i=0; i<colNum; i++){
      memcpy(buffer, &data[i][j+startLine], sizeof(int64_t));
      result.append(buffer, sizeof(int64_t));
    }
  }
  return result;
}


std::set<int> parser(std::string& columns){
  std::set<int> result;
  std::string leftStr = columns;
  while(leftStr.size() != 0){
    std::size_t pos = leftStr.find(',');
    if(pos == std::string::npos){
      int colNumber = std::stoi(leftStr);
      result.insert(colNumber);
      break;
    }else{
      std::string numberStr = leftStr.substr(0, pos);
      int colNumber = std::stoi(numberStr);
      result.insert(colNumber);
      leftStr = leftStr.substr(pos+1);
    }
  }

  return result;
}

int ColumnCompression(int64_t* col, int length){
  int min = col[0], max = col[0];
  for(int j=1; j<length; j++){
    if(min > col[j]) min = col[j];
    if(max < col[j]) max = col[j];
  }
  uint64_t delta = max - min;
  int level = 0;

  while(true){
    if((delta >> level) != 0){
      level++;
    }else{
      break;
    }
  }

  return level * length + 8 * 8;
}

std::vector<int64_t> ColumnCompressionData(int64_t* col, int length){
  int min = col[0], max = col[0];
  for(int j=1; j<length; j++){
    if(min > col[j]) min = col[j];
    if(max < col[j]) max = col[j];
  }
  uint64_t delta = max - min;
  int level = 0;

  std::vector<int64_t> result;

  for(int i=0; i<length; i++){
    result.push_back(col[i]-min);
  }

  return result;
}

//int ColumnCompression(int64_t* col, int length){
//  int min = col[0], max = col[0];
//  for(int j=1; j<length; j++){
//    if(min > col[j]) min = col[j];
//    if(max < col[j]) max = col[j];
//  }
//  uint64_t delta = max - min;
//
//  int result = 0;
//  char buffer[16];
//  for(int j=0; j<length; j++){
//    int n = varint_write_u(buffer, col[j]-min);
//    result += n;
//  }
//
//  return result;
//
//}

int BaseCompression(const std::vector<std::vector<int64_t>>& data, uint64_t startLine){
//  printf("BaseCompression\n");
  int cost = 0;
  int index = 0;

  int batchsize = 0;
  int leftLines = data.begin()->size() - startLine;
  if(leftLines < FLAGS_BatchSize){
    batchsize = leftLines;
  }else{
    batchsize = FLAGS_BatchSize;
  }

  for(auto item : data){
    int costLocal = ColumnCompression(item.data(), batchsize);
//    printf("Line #%d: %d bytes\n", index, costLocal);
    cost += costLocal;
    index++;
  }
//  printf("BaseTotal: %d bytes\n", cost);
  return cost;
}

int BaseCompression_LZ4(const std::vector<std::vector<int64_t>>& data, uint64_t startLine){
//  printf("BaseCompression\n");
  int cost = 0;
  int index = 0;

  int batchsize = 0;
  int leftLines = data.begin()->size() - startLine;
  if(leftLines < FLAGS_BatchSize){
    batchsize = leftLines;
  }else{
    batchsize = FLAGS_BatchSize;
  }

  std::vector<std::vector<int64_t>> temp;

  for(auto item : data){
    auto colResult = ColumnCompressionData(item.data(), batchsize);
    temp.push_back(colResult);
    index++;
  }
  char* buffer = (char*)malloc(4096);
  std::string str = ArrayToString(temp, 0, FLAGS_BatchSize, temp.size());
  int r = LZ4_compress_default(str.data(), buffer, str.size(), 4096);
  assert(r != 0);
  free(buffer);

//  printf("BaseTotal: %d bytes\n", cost);
  return r;
}

int LinearCompression(const std::vector<std::vector<int64_t>>& data, uint64_t startLine){
//  printf("LinearCompression\n");
  int cost = 0;
  int index = 0;

  int batchsize = 0;
  int leftLines = data.begin()->size() - startLine;
  if(leftLines < FLAGS_BatchSize){
    batchsize = leftLines;
  }else{
    batchsize = FLAGS_BatchSize;
  }

  for(auto item : data){
    LinearSolver2 linearSolver(batchsize, &item[startLine]);
    double k = linearSolver.getK();
    double b = linearSolver.getB();
    std::vector<int64_t> result;
    for(int i=0; i<batchsize; i++){
      int predict = lround(k * i + b);
      int delta = item[startLine + i] - predict;
      result.push_back(delta);
    }
    int costLocal = ColumnCompression(result.data(), batchsize);
//    printf("Line #%d: %d bytes\n", index, costLocal);
    cost += costLocal;
    index++;
  }
//  printf("LinearTotal: %d bytes\n", cost);
  return cost;
}

int LinearCompression_LZ4(const std::vector<std::vector<int64_t>>& data, uint64_t startLine){
//  printf("LinearCompression\n");
  int cost = 0;
  int index = 0;

  int batchsize = 0;
  int leftLines = data.begin()->size() - startLine;
  if(leftLines < FLAGS_BatchSize){
    batchsize = leftLines;
  }else{
    batchsize = FLAGS_BatchSize;
  }

  std::vector<std::vector<int64_t>> temp;

  for(auto item : data){
    LinearSolver2 linearSolver(batchsize, &item[startLine]);
    double k = linearSolver.getK();
    double b = linearSolver.getB();
    std::vector<int64_t> result;
    for(int i=0; i<batchsize; i++){
      int predict = lround(k * i + b);
      int delta = item[startLine + i] - predict;
      result.push_back(delta);
    }
    auto colResult = ColumnCompressionData(result.data(), batchsize);
    temp.push_back(colResult);
    index++;
  }

  char* buffer = (char*)malloc(4096);
  std::string str = ArrayToString(temp, 0, FLAGS_BatchSize, temp.size());
  int r = LZ4_compress_default(str.data(), buffer, str.size(), 4096);
  assert(r != 0);
  free(buffer);

//  printf("LinearTotal: %d bytes\n", cost);
  return r;
}

int ReorderLinearCompression(const std::vector<std::vector<int64_t>>& data, int startLine, int colNum){
//  printf("ReorderLinearCompression\n");
  int cost = 0;
  int index = 0;

  int batchsize = 0;
  int leftLines = data.begin()->size() - startLine;
  if(leftLines < FLAGS_BatchSize){
    batchsize = leftLines;
  }else{
    batchsize = FLAGS_BatchSize;
  }

  auto batchReordered = BatchReorder(data, startLine, batchsize, colNum);
  for(auto item : batchReordered){
    LinearSolver2 linearSolver(batchsize, &item[0]);
    double k = linearSolver.getK();
    double b = linearSolver.getB();
    std::vector<int64_t> result;
    for(int i=0; i<batchsize; i++){
      int predict = lround(k * i + b);
      int delta = item[i] - predict;
      result.push_back(delta);
    }
    int costLocal = ColumnCompression(result.data(), batchsize);
//    printf("Line #%d: %d bytes\n", index, costLocal);
    cost += costLocal;
    index++;
  }
//  printf("ReorderLinearTotal: %d bytes\n", cost);
  return cost;
}

int ReorderLinearCompression_LZ4(const std::vector<std::vector<int64_t>>& data, int startLine, int colNum){
//  printf("ReorderLinearCompression\n");
  int cost = 0;
  int index = 0;

  int batchsize = 0;
  int leftLines = data.begin()->size() - startLine;
  if(leftLines < FLAGS_BatchSize){
    batchsize = leftLines;
  }else{
    batchsize = FLAGS_BatchSize;
  }

  std::vector<std::vector<int64_t>> temp;

  auto batchReordered = BatchReorder(data, startLine, batchsize, colNum);
  for(auto item : batchReordered){
    LinearSolver2 linearSolver(batchsize, &item[0]);
    double k = linearSolver.getK();
    double b = linearSolver.getB();
    std::vector<int64_t> result;
    for(int i=0; i<batchsize; i++){
      int predict = lround(k * i + b);
      int delta = item[i] - predict;
      result.push_back(delta);
    }
    auto colResult = ColumnCompressionData(result.data(), batchsize);
    temp.push_back(colResult);
    index++;
  }

  char* buffer = (char*)malloc(4096);
  std::string str = ArrayToString(temp, 0, FLAGS_BatchSize, temp.size());
  int r = LZ4_compress_default(str.data(), buffer, str.size(), 4096);
  assert(r != 0);
  free(buffer);

//  printf("ReorderLinearTotal: %d bytes\n", cost);
  return r;
}

int ReorderLinearCompression_LZ42(const std::vector<std::vector<int64_t>>& data, int startLine, int colNum){
//  printf("ReorderLinearCompression\n");
  int cost = 0;
  int index = 0;

  int batchsize = 0;
  int leftLines = data.begin()->size() - startLine;
  if(leftLines < FLAGS_BatchSize){
    batchsize = leftLines;
  }else{
    batchsize = FLAGS_BatchSize;
  }

  std::vector<std::vector<int64_t>> temp;
  std::vector<bool> valid;
  int counter = 0;

  auto batchReordered = BatchReorder2(data, startLine, batchsize, colNum, &valid);
  for(auto item : batchReordered){
    if(valid[counter]){

    }
    LinearSolver2 linearSolver(batchsize, &item[0]);
    double k = linearSolver.getK();
    double b = linearSolver.getB();
    std::vector<int64_t> result;
    for(int i=0; i<batchsize; i++){
      int predict = lround(k * i + b);
      int delta = item[i] - predict;
      result.push_back(delta);
    }
    auto colResult = ColumnCompressionData(item.data(), batchsize);
    temp.push_back(colResult);
    index++;
  }

  char* buffer = (char*)malloc(4096);
  std::string str = ArrayToString(temp, 0, FLAGS_BatchSize, temp.size());
  int r = LZ4_compress_default(str.data(), buffer, str.size(), 4096);
  assert(r != 0);
  free(buffer);

//  printf("ReorderLinearTotal: %d bytes\n", cost);
  return r;
}

int ReorderCompression(const std::vector<std::vector<int64_t>>& data, int startLine, int colNum){
  int cost = 0;
  int index = 0;

  int batchsize = 0;
  int leftLines = data.begin()->size() - startLine;
  if(leftLines < FLAGS_BatchSize){
    batchsize = leftLines;
  }else{
    batchsize = FLAGS_BatchSize;
  }

  auto batchReordered = BatchReorder(data, startLine, batchsize, colNum);

  std::string str = ArrayToString(batchReordered, 0, FLAGS_BatchSize, batchReordered.size());
  char* buffer = (char*)malloc(4096);
  int r = LZ4_compress_default(str.data(), buffer, str.size(), 4096);
  assert(r != 0);
  free(buffer);

  return r;

}

int main(int argc, char **argv) {

  gflags::ParseCommandLineFlags(&argc, &argv, true);
  std::cout << "Batch path: " << FLAGS_InputFile << std::endl;

  std::set<int> colNumbers = parser(FLAGS_Columns);

  rapidcsv::Document doc(FLAGS_InputFile);

  std::vector<std::vector<int64_t>> data;

  for(auto item : colNumbers){
    std::vector<int64_t> col = doc.GetColumn<int64_t>(item);
    data.push_back(col);
  }

  uint64_t count = data.begin()->size();
  uint64_t batchNum = count/FLAGS_BatchSize;

  int baseCount = 0, linearCount = 0, reorderLinearCount = 0;
  char* buffer = (char*)malloc(4096);
  int r = 0;

  for(int i=0; i<batchNum; i++){
    BaseCompression(data, i*FLAGS_BatchSize);
    std::string base = ArrayToString(data, i*FLAGS_BatchSize, FLAGS_BatchSize, data.size());
    r = LZ4_compress_default(base.data(), buffer, base.size(), 4096);
    assert(r!=0);
    baseCount += r;

    reorderLinearCount += ReorderCompression(data, i*FLAGS_BatchSize, data.size());
  }
  printf("Direct LZ4 Base:%d, Reorder:%d\n", baseCount, reorderLinearCount);

  baseCount = 0, reorderLinearCount = 0;

  for(int i=0; i<batchNum; i++){
    baseCount += BaseCompression_LZ4(data, i*FLAGS_BatchSize);
    linearCount += LinearCompression_LZ4(data, i*FLAGS_BatchSize);
    reorderLinearCount += ReorderLinearCompression_LZ4(data, i*FLAGS_BatchSize, data.size());
  }

  printf("Base:%d, Linear:%d, ReorderLinear:%d\n", baseCount, linearCount, reorderLinearCount);

}
