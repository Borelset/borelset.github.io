#include <iostream>
#include <fstream>
#include "gflags/gflags.h"
#include <unordered_map>
#include <unordered_set>
#include <set>
#include <algorithm>
#include "Odess.h"
#include "FileOperator.h"
#include "lz4-1.9.4/lib/lz4.h"
#include "OffsetList.h"

DEFINE_string(InputFile, "", "batch process file path");
DEFINE_int32(BatchSize, 20, "batch process file path");

struct Feature{
    uint64_t ff[SuperFeatureNum];
};

struct Entry{
    std::string ss;
    Feature ft;
};

bool EntryComparor(const Entry& el, const Entry& er){
  return el.ss < er.ss;
}

bool mycompare(const Entry &lhs, const Entry &rhs) {
  for(int i=0; i<SuperFeatureNum; i++){
    if(lhs.ft.ff[i] < rhs.ft.ff[i]) return true;
    else if(lhs.ft.ff[i] > rhs.ft.ff[i]) return false;
  }
  return true;
}

std::string offsetPath(std::string filepath){
  size_t off = filepath.find('.');
  std::string result = filepath.substr(0, off);
  result += "_offset.csv";
  return result;
}

std::vector<Entry> data;

#include "Reorder.h"

int main(int argc, char **argv) {
  gflags::ParseCommandLineFlags(&argc, &argv, true);
  std::ifstream infile;
  infile.open(FLAGS_InputFile);
  std::string rowData;
  uint64_t counter = 0;
  std::cout << "File path: " << FLAGS_InputFile << std::endl;

  char* compressionBuffer = (char*)malloc(20971520);
  char* compressionBuffer2 = (char*)malloc(20971520);
  uint64_t pos = 0;
  uint64_t rawBefore = 0, rawAfter = 0, shuffleBefore = 0, shuffleAfter = 0, reorderBefore = 0, reorderAfter = 0;

  printf("BatchSize: %d\n", FLAGS_BatchSize);

  std::set<int> allowList = getAllowList(offsetPath(FLAGS_InputFile));

  while (std::getline(infile, rowData)) {
    Feature tmpf;
    odessCalculation((uint8_t*)rowData.data(), (uint64_t)rowData.length(), (uint64_t*)&tmpf, allowList);
    data.push_back({rowData, tmpf});
    counter++;
  }

  printf("Normal Order..\n");

  for(int i=0; i<counter; i++){
    std::string comstr = data[i].ss + "\n";
    memcpy(compressionBuffer + pos, comstr.data(), comstr.length());
    pos += comstr.length();
    if(i % FLAGS_BatchSize == FLAGS_BatchSize - 1){
      rawBefore += pos;
      int r = LZ4_compress_default(compressionBuffer, compressionBuffer2, pos, 20971520);
      assert(r != 0);
      rawAfter += r;
      pos = 0;
    }
  }

  if(pos != 0){
    rawBefore += pos;
    int r = LZ4_compress_default(compressionBuffer, compressionBuffer2, pos, 20971520);
    assert(r != 0);
    rawAfter += r;
    pos = 0;
  }

  printf("Read %lu items..\n", counter);
  printf("Raw Compression: %lu => %lu, %f%%\n", rawBefore, rawAfter, (float)rawAfter*100/(float)rawBefore);

  printf("Shuffle Order..\n");
  shuffle(data);

  std::string shufflePath = FLAGS_InputFile + "_shuffled";
  FileOperator shuffleFile((char*)shufflePath.data(), FileOpenType::ReadWrite);

  for(int i=0; i<counter; i++){
    std::string comstr = data[i].ss + "\n";
    shuffleFile.write((uint8_t*)comstr.data(), comstr.size());

    memcpy(compressionBuffer + pos, comstr.data(), comstr.length());
    pos += comstr.length();
    if(i % FLAGS_BatchSize == FLAGS_BatchSize - 1){
      shuffleBefore += pos;
      int r = LZ4_compress_default(compressionBuffer, compressionBuffer2, pos, 20971520);
      assert(r != 0);
      shuffleAfter += r;
      pos = 0;
    }
  }

  if(pos != 0){
    shuffleBefore += pos;
    int r = LZ4_compress_default(compressionBuffer, compressionBuffer2, pos, 20971520);
    assert(r != 0);
    shuffleAfter += r;
    pos = 0;
  }

  printf("Read %lu items..\n", counter);
  printf("Shuffle Compression: %lu => %lu, %f%%\n", shuffleBefore, shuffleAfter, (float)shuffleAfter*100/(float)shuffleBefore);



  std::string reorderPath = FLAGS_InputFile + "_reordered_" + std::to_string(FLAGS_LowerLimit) + "_" + std::to_string(FLAGS_UpperLimit);
  FileOperator reorderFile((char*)reorderPath.data(), FileOpenType::ReadWrite);

  //std::sort(data.begin(), data.end(), mycompare);

  printf("Similarity Order..\n");

  data = reorder(data);

  counter = 0;
  for(auto item: data){
    std::string comstr = item.ss + "\n";
    reorderFile.write((uint8_t*)comstr.data(), comstr.size());
    memcpy(compressionBuffer + pos, comstr.data(), comstr.length());
    pos += comstr.length();
    if(counter % FLAGS_BatchSize == FLAGS_BatchSize - 1){
      reorderBefore += pos;
      int r = LZ4_compress_default(compressionBuffer, compressionBuffer2, pos, 20971520);
      assert(r != 0);
      reorderAfter += r;
      pos = 0;
    }
    counter++;
  }
  if(pos != 0){
    reorderBefore += pos;
    int r = LZ4_compress_default(compressionBuffer, compressionBuffer2, pos, 20971520);
    assert(r != 0);
    reorderAfter += r;
    pos = 0;
  }
  printf("Write %lu items..\n", counter);
  printf("Reorder Compression: %lu => %lu, %f%%\n", reorderBefore, reorderAfter, (float)reorderAfter*100/(float)reorderBefore);

}
