//
// Created by BorelsetR on 2019/11/13.
//

#ifndef BENCH_CHUNKGENERATOR_H
#define BENCH_CHUNKGENERATOR_H

#include <random>

struct Chunk{
    uint8_t* buffer;
    uint64_t length;
};

class ChunkGenerator{
public:
    ChunkGenerator():byteDistribution(0, 255){

    }

    void setup(double expect, double n){
        std::normal_distribution<double>::param_type param(expect, n);
        distribution.param(param);
    }

    Chunk gen(){
        uint64_t length = std::lround(distribution(engine));
        Chunk chunk = {
                .buffer = (uint8_t*)malloc(length),
                .length = length,
        };
        for(int i=0; i<length; i++){
            chunk.buffer[i] = byteDistribution(engine);
        }
        return chunk;
    }

private:
    std::uniform_int_distribution<uint64_t> byteDistribution;
    std::normal_distribution<double> distribution;
    std::default_random_engine engine;

};

#endif //BENCH_CHUNKGENERATOR_H
