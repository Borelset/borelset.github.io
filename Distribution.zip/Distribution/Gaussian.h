//
// Created by BorelsetR on 2019/11/12.
//

#ifndef BENCH_GAUSSIAN_H
#define BENCH_GAUSSIAN_H

#define PI (3.1415926)
#define PI2 (9.8696040)
#define GAUSS_ARG (0.3990434)

#include <cmath>
#include <cassert>

class Gaussian{
public:
    Gaussian(double u, double n):
        mu(u), sigma(n), sigma2(n*n)
    {
        assert(mu < 1);
        assert(mu > -1);
    }

    void setup(uint64_t length){
        uint64_t mid = length >> 1;
        if(mu > 0){
            norm_center = mid + (length-mid) * mu;
        }else {
            norm_center = mid * (1 - mu);
        }
    }

    double prop(uint64_t pos){
        return
        GAUSS_ARG / sigma *
        exp(
                -(float)(pos-norm_center)*(pos-norm_center)
                /
                (2*sigma2)
        );
    }
private:
    double mu;
    double sigma;
    double sigma2;
    int64_t norm_center;
};

#endif //BENCH_GAUSSIAN_H
