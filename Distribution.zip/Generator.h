//
// Created by BorelsetR on 2019/11/12.
//

#ifndef BENCH_GENERATOR_H
#define BENCH_GENERATOR_H

#include "Distribution/Gaussian.h"
#include <list>
#include <random>
#include <cstring>

struct GenResult{
    uint8_t* buffer;
    uint64_t resultLength;
    uint64_t operators;
    float ratio1;
    float ratio2;
    float ratiod;
    uint64_t before;
    uint64_t after;
    uint64_t realCommon;
};

enum class OperatorType{
    Insert,
    Replace,
    Delete,
};

struct Operator{
    uint64_t pos;
    OperatorType operatorType;
    uint64_t length;
};

class Generator{
public:
    Generator(double u, double n, double r, uint64_t length):gaussian(u, n), rate(r){
        std::uniform_real_distribution<float>::param_type operatorParam(0, 1);
        std::uniform_int_distribution<uint64_t>::param_type typeParam(0, 2);
        std::uniform_int_distribution<uint64_t>::param_type lengthParam(length - 100, length + 100);
        std::uniform_int_distribution<uint64_t>::param_type byteParam(0, 255);
        operatorDistribution.param(operatorParam);
        typeDistribution.param(typeParam);
        byteDistribution.param(byteParam);
        lengthDistribution.param(lengthParam);
    }

    GenResult gen(uint8_t* buffer, uint64_t length){
        uint64_t unchangedBytes = 0;
        std::list<Operator> operatorList;
        uint64_t upper = createOperator(length, &operatorList);
        uint8_t* resultBuffer = (uint8_t*)malloc(upper);
        uint64_t outputLength = 0;
        uint64_t pos = 0, ptr = 0;
        uint64_t operatorCounter = 0;
        uint64_t realCommon = 0;

        for(const Operator& optr : operatorList){
            if(ptr > length) break;
            if(optr.pos < ptr) continue;
            memcpy(resultBuffer+pos, buffer+ptr, optr.pos-ptr);
            realCommon += optr.pos-ptr;
            if(pos + optr.pos - ptr > upper){
                assert(1);
            }
            //printf("copy @ %lu, length=%lu\n", ptr, optr.pos-ptr);
            outputLength += optr.pos-ptr;
            unchangedBytes += optr.pos - ptr;
            pos += optr.pos-ptr;
            ptr += optr.pos-ptr;
            operatorCounter++;
            uint64_t replaceLength;
            switch (optr.operatorType){
                case OperatorType::Insert:
                    for(uint64_t i=0; i<optr.length; i++){
                        resultBuffer[pos+i] = byteDistribution(randomEngine);
                        if(pos + i > upper){
                            assert(1);
                        }
                    }
                    pos += optr.length;
                    outputLength += optr.length;
                    //printf("Insert @ %lu, length=%lu\n", optr.pos, optr.length);
                    break;
                case OperatorType::Replace:
                    replaceLength = std::min(length - optr.pos, optr.length);
                    for(uint64_t i=0; i<replaceLength; i++){
                        resultBuffer[pos+i] = byteDistribution(randomEngine);
                        if(pos + i > upper){
                            assert(1);
                        }
                    }
                    pos += replaceLength;
                    ptr += replaceLength;
                    outputLength += replaceLength;
                    //printf("Replace @ %lu, length=%lu\n", optr.pos, optr.length);
                    break;
                case OperatorType::Delete:
                    ptr += optr.length;
                    //printf("Delete @ %lu, length=%lu\n", optr.pos, optr.length);
                    break;
            }
        }
        if(ptr < length-1){
            memcpy(resultBuffer+pos, buffer+ptr, length-ptr);
            realCommon += length-ptr;
            if(pos + length-ptr > upper){
                assert(1);
            }
            //printf("copy @ %lu, length=%lu\n", ptr, length-ptr);
            outputLength += length-ptr;
            unchangedBytes += length-ptr;
        }
        GenResult genResult = {
                .buffer = resultBuffer,
                .resultLength = outputLength,
                .operators = operatorCounter,
                .ratio1 = (float)unchangedBytes / length,
                .ratio2 = (float)unchangedBytes / outputLength,
                .ratiod = (float)unchangedBytes / (length + outputLength - unchangedBytes),
                .before = length,
                .after = outputLength,
                .realCommon = realCommon,
        };
        return genResult;
    }
private:
    double rate;
    Gaussian gaussian;
    std::default_random_engine randomEngine;
    std::uniform_real_distribution<float> operatorDistribution;
    std::uniform_int_distribution<uint64_t> typeDistribution;
    std::uniform_int_distribution<uint64_t> byteDistribution;
    std::uniform_int_distribution<uint64_t> lengthDistribution;

    uint64_t createOperator(uint64_t length, std::list<Operator>* result){
        uint64_t totalLength_upper = length;
        Operator tempOperator;
        float randFactor = 0;
        uint32_t condition = 0;
        uint32_t type = 0;
        gaussian.setup(length);
        for(uint64_t i=0; i<length; i++){
            //condition = 100 * gaussian.prop(i) * rate;
            randFactor = operatorDistribution(randomEngine);
            if(randFactor < rate){
                tempOperator.pos = i;
                tempOperator.length = lengthDistribution(randomEngine);
                type = typeDistribution(randomEngine);

                switch (type){
                    case 0:
                        tempOperator.operatorType = OperatorType ::Insert;
                        totalLength_upper += tempOperator.length;
                        break;
                    case 1:
                        tempOperator.operatorType = OperatorType ::Replace;
                        break;
                    case 2:
                        tempOperator.operatorType = OperatorType ::Delete;
                        break;
                }
                result->push_back(tempOperator);
            }
        }
        return totalLength_upper;
    }
};

#endif //BENCH_GENERATOR_H
