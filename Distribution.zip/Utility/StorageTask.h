//
// Created by BorelsetR on 2019/7/23.
//

#ifndef ODESS_COMPRESSIONTASK_H
#define ODESS_COMPRESSIONTASK_H

#include "Chunk.h"
#include "Lock.h"
#include <list>
#include <tuple>

enum class TaskType {
    Compression,
    Decompression,
};

struct WriteChunkHead {
    uint8_t type;
    uint64_t fp;
    uint64_t pos;
    uint64_t length;
};

struct SHA1FP {
    //std::tuple<uint32_t, uint32_t, uint32_t, uint32_t, uint32_t> fp;
    uint64_t fp1;
    uint32_t fp2, fp3, fp4;
};

/*
bool operator == (const SHA1FP& left, const SHA1FP& right)
{
    if(left.fp[0] == right.fp[0] &&
            left.fp[1] == right.fp[1] &&
            left.fp[2] == right.fp[2] &&
            left.fp[3] == right.fp[3] &&
            left.fp[4] == right.fp[4]){
        return true;
    }else{
        return false;
    }
}

bool operator < (const SHA1FP& left, const SHA1FP& right)
{
    for(int i=0; i<5; i++){
        if(left.fp[i] < right.fp[i]){
            return true;
        }
    }
    return false;
}
 */

struct SFSet {
    uint64_t sf[32];
};

struct StageTimePoint {
    uint64_t read = 0;
    uint64_t chunk = 0;
    uint64_t dedup = 0;
    uint64_t write = 0;
};

struct Location {
    uint64_t fid;
    uint64_t pos;
    uint64_t length;
};

struct BlockHead {
    SHA1FP sha1Fp;
    uint8_t type;
    uint32_t length;
};

struct DedupTask {
    uint8_t *buffer;
    uint64_t pos;
    uint64_t length;
    SHA1FP fp;
    uint64_t fileID;
    StageTimePoint *stageTimePoint;
    CountdownLatch *countdownLatch = nullptr;
    uint64_t index;
};

struct WriteTask {
    int type;
    Location location;
    uint8_t *buffer;
    uint64_t pos;
    uint64_t bufferLength;
    uint8_t *deltaBuffer;
    uint64_t deltaBufferLength;
    uint64_t fileID;
    SHA1FP sha1Fp;
    uint64_t sf1;
    uint64_t sf2;
    uint64_t sf3;
    uint64_t sf4;
    uint64_t sf5;
    uint64_t sf6;
    uint64_t sf7;
    uint64_t sf8;
    uint64_t sf9;
    uint64_t sf10;
    uint64_t sf11;
    uint64_t sf12;
    StageTimePoint *stageTimePoint;
    CountdownLatch *countdownLatch = nullptr;
    uint64_t index;
};

struct ChunkTask {
    uint8_t *buffer = nullptr;
    uint64_t length;
    uint64_t fileID;
    uint64_t end;
    CountdownLatch *countdownLatch = nullptr;
    uint64_t index;
};

struct StorageTask {
    std::string path;
    uint8_t *buffer = nullptr;
    uint64_t length;
    uint64_t fileID;
    uint64_t end;
    CountdownLatch *countdownLatch = nullptr;
    StageTimePoint stageTimePoint;

    void destruction() {
        if (buffer) free(buffer);
    }
};

struct RestoreTask {
    std::string path;
    std::string outputPath;
    CountdownLatch *countdownLatch = nullptr;
};

#endif //ODESS_COMPRESSIONTASK_H
