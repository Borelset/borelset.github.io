#include <iostream>
#include "Generator.h"
#include "ChunkGenerator.h"
#include "FileOperator.h"
#include "gflags/gflags.h"
#include "FeatureMethod/NFeatureSample.h"
#include "FeatureMethod/NFeature.h"
#include "FeatureMethod/FinesseFeature.h"
#include "RollHash/Gear.h"

DEFINE_string(Path1, "/home/zxy/DetectTest/chunk1/%lu", "");
DEFINE_string(Path2, "/home/zxy/DetectTest/chunk2/%lu", "");
DEFINE_string(OutFile, "statistics", "");
DEFINE_string(PathStatistics, "/home/zxy/DetectTest/", "");
DEFINE_int32(ExpectLength, 8192, "");
DEFINE_double(Sigma, 500, "");
DEFINE_uint64(Count, 10000, "");
DEFINE_uint64(Feature, 12, "");
DEFINE_int32(ML, 100, "");
DEFINE_double(MR, 0.0005, "");

char format[] = "similarity1:%f\tsimilarity2:%f\tsimilarityd:%f\toperators:%lu\tbefore:%lu\tafter:%lu\tf:%d/%d\ts:%d/%d\tn:%d/%d\n";

int main(int argc, char* argv[]) {
    gflags::ParseCommandLineFlags(&argc, &argv, true);
    char Fpath[1024];
    sprintf(Fpath,"%s/1_%f_%d_%d", FLAGS_PathStatistics.data(), FLAGS_MR, FLAGS_ML, FLAGS_Feature);
//    std::string Fpath = FLAGS_PathStatistics;
//    Fpath += FLAGS_OutFile;
    ChunkGenerator chunkGenerator;
    chunkGenerator.setup(FLAGS_ExpectLength, FLAGS_Sigma);
    FileOperator fileStatistics((char*)Fpath, FileOpenType::Write);
    printf("path:%s\n", Fpath);


    FinesseFeature finesseFeature(FLAGS_Feature, nullptr);
    NFeature nFeature(FLAGS_Feature, nullptr);
    NFeatureSample nFeatureSample(FLAGS_Feature, new Gear());

    float min_f1 = 0, square_f1 = 0, min_f2 = 0, square_f2 = 0, min_fd = 0, square_fd = 0;
    float min_s1 = 0, square_s1 = 0, min_s2 = 0, square_s2 = 0, min_sd = 0, square_sd = 0;
    float min_n1 = 0, square_n1 = 0, min_n2 = 0, square_n2 = 0, min_nd = 0, square_nd = 0;

    float tmin_f1 = 0, tsquare_f1 = 0, tmin_f2 = 0, tsquare_f2 = 0, tmin_fd = 0, tsquare_fd = 0;
    float tmin_s1 = 0, tsquare_s1 = 0, tmin_s2 = 0, tsquare_s2 = 0, tmin_sd = 0, tsquare_sd = 0;
    float tmin_n1 = 0, tsquare_n1 = 0, tmin_n2 = 0, tsquare_n2 = 0, tmin_nd = 0, tsquare_nd = 0;

    char path[256];
    char statisticsBuffer[1024];

    //Generator generator(0, 2000, 50000, 100);
    Generator generator(0, 2000, FLAGS_MR, FLAGS_ML);
    //Generator generator(0, 0, 0, 0);

    for(uint64_t i=0; i<FLAGS_Count; i++){
        if(i%1000==0) printf("%lu/%lu\n", i, FLAGS_Count);
        Chunk chunk = chunkGenerator.gen();
        GenResult genResult = generator.gen(chunk.buffer, chunk.length);

        SFSet feature1, feature2;
        finesseFeature.setTotalLength(chunk.length);
        finesseFeature.detect(chunk.buffer, chunk.length);
        finesseFeature.getResult(&feature1);
        finesseFeature.setTotalLength(genResult.resultLength);
        finesseFeature.detect(genResult.buffer, genResult.resultLength);
        finesseFeature.getResult(&feature2);
        int fCount = 0;
        for(int j=0; j<FLAGS_Feature; j++){
            if(feature1.sf[j] == feature2.sf[j]) fCount++;
        }
        float rate = (float)fCount / (FLAGS_Feature * 2 - fCount);

        nFeatureSample.setTotalLength(chunk.length);
        nFeatureSample.detect(chunk.buffer, chunk.length);
        nFeatureSample.getResult(&feature1);
        nFeatureSample.setTotalLength(genResult.resultLength);
        nFeatureSample.detect(genResult.buffer, genResult.resultLength);
        nFeatureSample.getResult(&feature2);
        int sCount = 0;
        for(int j=0; j<FLAGS_Feature; j++){
            if(feature1.sf[j] == feature2.sf[j]) sCount++;
        }

        nFeature.setTotalLength(chunk.length);
        nFeature.detect(chunk.buffer, chunk.length);
        nFeature.getResult(&feature1);
        nFeature.setTotalLength(genResult.resultLength);
        nFeature.detect(genResult.buffer, genResult.resultLength);
        nFeature.getResult(&feature2);
        int nCount = 0;
        for(int j=0; j<FLAGS_Feature; j++){
            if(feature1.sf[j] == feature2.sf[j]) nCount++;
        }

        sprintf(statisticsBuffer, format, genResult.ratio1, genResult.ratio2, genResult.ratiod, genResult.operators, genResult.before, genResult.after, fCount, FLAGS_Feature, sCount, FLAGS_Feature, nCount, FLAGS_Feature);
        fileStatistics.write((uint8_t*)statisticsBuffer, strlen(statisticsBuffer));

        tmin_f1 = fabsf(genResult.ratio1 - rate);
        tsquare_f1 = tmin_f1*tmin_f1;
        tmin_f2 = fabsf(genResult.ratio2 - rate);
        tsquare_f2 = tmin_f2*tmin_f2;
        tmin_fd = fabsf(genResult.ratiod - rate);
        tsquare_fd = tmin_fd*tmin_fd;
        min_f1 += tmin_f1;
        square_f1 += tsquare_f1;
        min_f2 += tmin_f2;
        square_f2 += tsquare_f2;
        min_fd += tmin_fd;
        square_fd += tsquare_fd;

        tmin_n1 = fabsf(genResult.ratio1 - (float)nCount/FLAGS_Feature);
        tsquare_n1 = tmin_n1*tmin_n1;
        tmin_n2 = fabsf(genResult.ratio2 - (float)nCount/FLAGS_Feature);
        tsquare_n2 = tmin_n2*tmin_n2;
        tmin_nd = fabsf(genResult.ratiod - (float)nCount/FLAGS_Feature);
        tsquare_nd = tmin_nd*tmin_nd;
        min_n1 += tmin_n1;
        square_n1 += tsquare_n1;
        min_n2 += tmin_n2;
        square_n2 += tsquare_n2;
        min_nd += tmin_nd;
        square_nd += tsquare_nd;

        tmin_s1 = fabsf(genResult.ratio1 - (float)sCount/FLAGS_Feature);
        tsquare_s1 = tmin_s1*tmin_s1;
        tmin_s2 = fabsf(genResult.ratio2 - (float)sCount/FLAGS_Feature);
        tsquare_s2 = tmin_s2*tmin_s2;
        tmin_sd = fabsf(genResult.ratiod - (float)sCount/FLAGS_Feature);
        tsquare_sd = tmin_sd*tmin_sd;
        min_s1 += tmin_s1;
        square_s1 += tsquare_s1;
        min_s2 += tmin_s2;
        square_s2 += tsquare_s2;
        min_sd += tmin_sd;
        square_sd += tsquare_sd;

        //sprintf(path, FLAGS_Path1.data(), i);
        //FileOperator fileOperator(path, FileOpenType::Write);
        //fileOperator.write(chunk.buffer, chunk.length);

        //sprintf(path, FLAGS_Path2.data(), i);
        //FileOperator fileOperator2(path, FileOpenType::Write);
        //fileOperator2.write(genResult.buffer, genResult.resultLength);

        free(chunk.buffer);
        free(genResult.buffer);
    }

    sprintf(statisticsBuffer, "================================Statistics==================================\n");
    fileStatistics.write((uint8_t*)statisticsBuffer, strlen(statisticsBuffer));
    sprintf(statisticsBuffer, "total:%lu chunks\n", FLAGS_Count);
    fileStatistics.write((uint8_t*)statisticsBuffer, strlen(statisticsBuffer));

    sprintf(statisticsBuffer, "min_f1:%f\tstandard_f1:%f\tmin_f2:%f\tstandard_f2:%f\tmin_fd:%f\tstandard_fd:%f\n", min_f1 / FLAGS_Count, sqrt(square_f1 / FLAGS_Count), min_f2 / FLAGS_Count, sqrt(square_f2 / FLAGS_Count), min_fd / FLAGS_Count, sqrt(square_fd / FLAGS_Count));
    fileStatistics.write((uint8_t*)statisticsBuffer, strlen(statisticsBuffer));
    sprintf(statisticsBuffer, "min_s1:%f\tstandard_s1:%f\tmin_s2:%f\tstandard_s2:%f\tmin_sd:%f\tstandard_sd:%f\n", min_s1 / FLAGS_Count, sqrt(square_s1 / FLAGS_Count), min_s2 / FLAGS_Count, sqrt(square_s2 / FLAGS_Count), min_sd / FLAGS_Count, sqrt(square_sd / FLAGS_Count));
    fileStatistics.write((uint8_t*)statisticsBuffer, strlen(statisticsBuffer));
    sprintf(statisticsBuffer, "min_n1:%f\tstandard_n1:%f\tmin_n2:%f\tstandard_n2:%f\tmin_nd:%f\tstandard_nd:%f\n", min_n1 / FLAGS_Count, sqrt(square_n1 / FLAGS_Count), min_n2 / FLAGS_Count, sqrt(square_n2 / FLAGS_Count), min_nd / FLAGS_Count, sqrt(square_nd / FLAGS_Count));
    fileStatistics.write((uint8_t*)statisticsBuffer, strlen(statisticsBuffer));


    return 0;
}