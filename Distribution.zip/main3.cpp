//
// Created by Borelset on 2022/6/30.
//

#include "gflags/gflags.h"
#include <iostream>
#include "Generator.h"
#include "ChunkGenerator.h"
#include "FileOperator.h"
#include "FeatureMethod/NFeatureSample.h"
#include "FeatureMethod/NFeature.h"
#include "FeatureMethod/FinesseFeature.h"
#include "RollHash/Gear.h"
#include "Distribution.h"
#include "xdelta/xdelta3.h"
#include "SFDistributionSolver.h"

DEFINE_string(OutFile, "statistics", "");
DEFINE_string(PathStatistics, "/home/zxy/DetectTest/", "");
DEFINE_int32(ExpectLength, 8192, "");
DEFINE_double(Sigma, 500, "");
DEFINE_uint64(Count, 200000, "");
DEFINE_uint64(Feature, 12, "");
DEFINE_int32(ML, 100, "");
DEFINE_double(MR, 0.0004, "");

struct Record{
    uint16_t baseLength;
    uint16_t chunkLength;
    uint8_t featureMatched;
    uint8_t SFMatched;

    Record(uint16_t a, uint16_t b, uint8_t c, uint8_t sf){
      baseLength = a;
      chunkLength = b;
      featureMatched = c;
      SFMatched = sf;
    }
};

char format[] = "similarityd:%f\toperators:%lu\tbefore:%lu\tafter:%lu\ts:%d/%d\trealcommon:%lu\treduce:%lu\n";

int main(int argc, char* argv[]) {
  gflags::ParseCommandLineFlags(&argc, &argv, true);
  char Fpath[1024];
  sprintf(Fpath,"%s/1_%f_%d_%d", FLAGS_PathStatistics.data(), FLAGS_MR, FLAGS_ML, FLAGS_Feature);
//    std::string Fpath = FLAGS_PathStatistics;
//    Fpath += FLAGS_OutFile;
  ChunkGenerator chunkGenerator;
  chunkGenerator.setup(FLAGS_ExpectLength, FLAGS_Sigma);
  FileOperator fileStatistics((char*)Fpath, FileOpenType::Write);
  printf("path:%s\n", Fpath);

  NFeatureSample nFeatureSample(FLAGS_Feature, new Gear());

  float min_sd = 0, square_sd = 0;

  float tmin_sd = 0, tsquare_sd = 0;

  uint64_t TotalReduce = 0;
  uint64_t TotalSize = 0;
  uint64_t featureReduce = 0;
  uint64_t XDReduce = 0;

  char path[256];
  char statisticsBuffer[1024];

  //Generator generator(0, 2000, 50000, 100);
  Generator generator(0, 2000, FLAGS_MR, FLAGS_ML);
  //Generator generator(0, 0, 0, 0);

  int64_t* FeatureCounter = (int64_t*)malloc(sizeof(int64_t) * (FLAGS_Feature + 1));
  int64_t* SFCounter = (int64_t*)malloc(sizeof(int64_t) * (FLAGS_Feature/4));
  memset(FeatureCounter, 0, sizeof(int64_t) * (FLAGS_Feature + 1));
  memset(SFCounter, 0, sizeof(int64_t) * (FLAGS_Feature/4));

  std::list<Record> featureList;

  uint64_t RealCounted = 0;

  for(uint64_t i=0; i<FLAGS_Count; i++){
    if(i%1000==0) printf("%lu/%lu\n", i, FLAGS_Count);
    Chunk chunk = chunkGenerator.gen();
    GenResult genResult = generator.gen(chunk.buffer, chunk.length);

    SFSet feature1, feature2;

    nFeatureSample.setTotalLength(chunk.length);
    nFeatureSample.detect(chunk.buffer, chunk.length);
    nFeatureSample.getResult(&feature1);
    nFeatureSample.setTotalLength(genResult.resultLength);
    nFeatureSample.detect(genResult.buffer, genResult.resultLength);
    nFeatureSample.getResult(&feature2);
    int sCount = 0;
    for(int j=0; j<FLAGS_Feature; j++){
      if(feature1.sf[j] == feature2.sf[j]) sCount++;
    }
    FeatureCounter[sCount]++;
    bool tag = false;
    uint8_t sfm = 0;
    for(int j=0; j<FLAGS_Feature/4; j++){
      int r = memcmp(&(feature1.sf[j*4]), &(feature2.sf[j*4]), sizeof(uint64_t)*4);
      if(r == 0){
        tag = true;
        SFCounter[j]++;
        break;
      }
      sfm++;
    }

    if(tag == true){
      RealCounted++;

      featureList.emplace_back((uint16_t)chunk.length, (uint16_t)genResult.resultLength, (uint8_t)sCount, sfm);

      uint8_t* deltaBuffer = (uint8_t*)malloc(chunk.length + genResult.resultLength);
      usize_t deltaSize = 0;
      struct xdelta3_statistics output_statistics;
      xd3_encode_memory_statistics(genResult.buffer, genResult.resultLength, chunk.buffer, chunk.length, deltaBuffer, &deltaSize, chunk.length + genResult.resultLength, XD3_COMPLEVEL_1, &output_statistics);
      TotalReduce += output_statistics.l_scpy;
      TotalSize += genResult.resultLength;
      XDReduce += genResult.resultLength - deltaSize;
      featureReduce += (double)(genResult.resultLength + chunk.length) / (1.0 + ((double)FLAGS_Feature / sCount));
      free(deltaBuffer);

      sprintf(statisticsBuffer, format, genResult.ratiod, genResult.operators, genResult.before, genResult.after, sCount, FLAGS_Feature, genResult.realCommon, output_statistics.l_scpy);
      fileStatistics.write((uint8_t*)statisticsBuffer, strlen(statisticsBuffer));

      tmin_sd = fabsf(genResult.ratiod - (float)sCount/FLAGS_Feature);
      tsquare_sd = tmin_sd*tmin_sd;
      min_sd += tmin_sd;
      square_sd += tsquare_sd;
    }

    free(chunk.buffer);
    free(genResult.buffer);
  }

  sprintf(statisticsBuffer, "================================Statistics==================================\n");
  fileStatistics.write((uint8_t*)statisticsBuffer, strlen(statisticsBuffer));
  sprintf(statisticsBuffer, "total:%lu chunks\n", RealCounted);
  fileStatistics.write((uint8_t*)statisticsBuffer, strlen(statisticsBuffer));


  sprintf(statisticsBuffer, "min_sd:%f\tstandard_sd:%f\ttotalReduce:%lu\n", min_sd / RealCounted, sqrt(square_sd / RealCounted), TotalReduce);
  fileStatistics.write((uint8_t*)statisticsBuffer, strlen(statisticsBuffer));
  for(int i=0; i<=FLAGS_Feature; i++){
    printf("%d: %lu\n", i, FeatureCounter[i]);
  }
  for(int i=0; i<FLAGS_Feature/4; i++){
    printf("%d: %lu\n", i, SFCounter[i]);
  }

  SFDistributionSolver sfDistributionSolver(FLAGS_Feature, 3, SFCounter, 0);

  uint64_t estimatedReduce = 0;
  for(const auto& item: featureList){
    estimatedReduce += (double)(item.baseLength + item.chunkLength) / (1.0 / sfDistributionSolver.getFtoSim(item.SFMatched) + 1.0);
  }

  printf("EstimatedReduce = %lu, FeatureReduce = %lu, RealReduce = %lu, XDReduce = %lu, E/R loss = %f, F/R loss = %f, E/X loss = %f, F/X loss = %f\n", estimatedReduce, featureReduce, TotalReduce, XDReduce, fabs((double)estimatedReduce / TotalReduce -1), fabs((double)featureReduce / TotalReduce -1), fabs((double)estimatedReduce / XDReduce -1), fabs((double)featureReduce / XDReduce -1));
  printf("EstimatedRatio = %f, FeatureRatio = %f, RealRatio = %f, XDRatio = %f, E/R loss = %f, F/R loss = %f, E/X loss = %f, F/X loss = %f\n", (double)TotalSize / (TotalSize - estimatedReduce), (double)TotalSize / (TotalSize - featureReduce), (double)TotalSize / (TotalSize - TotalReduce), (double)TotalSize / (TotalSize - XDReduce), fabs((double)(TotalSize - TotalReduce) / (TotalSize - estimatedReduce) - 1), fabs((double)(TotalSize - TotalReduce) / (TotalSize - featureReduce) - 1), fabs((double)(TotalSize - XDReduce) / (TotalSize - estimatedReduce) - 1), fabs((double)(TotalSize - XDReduce) / (TotalSize - featureReduce) - 1));


  free(FeatureCounter);
  return 0;
}